// Product detail — shows the rebrand in context. Uses a "route graph" visualization
// that subtly leans into the graph metaphor.

const STEPS_STANDARD = [
  { idx: 1, name: "Diseño gráfico", machine: "CTP principal", note: "Opcional · Tiempo fijo", optional: true, done: true },
  { idx: 2, name: "Pre-prensa / armado", machine: "CTP principal", note: "Obligatorio · 10 min", done: true },
  { idx: 3, name: "Impresión por hoja", machine: "Ricoh PRO C5100", note: "Productividad de la máquina y perfil", done: true },
  { idx: 4, name: "Laminado", machine: "Laminadora BOPP rollo", note: "Opcional · Productividad", optional: true, done: true },
  { idx: 5, name: "Guillotina / corte", machine: "Polar 76", note: "Obligatorio · Tiempo fijo", done: true },
  { idx: 6, name: "Empaque", machine: "Mesa de empaque", note: "Obligatorio · Tiempo fijo", done: true },
  { idx: 7, name: "Despacho / QA", machine: "Mesa final", note: "Obligatorio · Tiempo fijo", done: true },
];

function Detail({ code, onBack, onEdit }) {
  return (
    <>
      <a className="back-link" onClick={onBack}>
        <Ico.Back /> Volver al catálogo
      </a>

      <div className="detail-head">
        <div className="title-block">
          <h1>Tarjetas de Visita Premium 300gr</h1>
          <div className="meta">
            <span className="code">{code}</span>
            <span>·</span>
            <span>Tarjetas de visita en papel opalina 300gr, 9×5cm</span>
          </div>
        </div>
        <div className="detail-actions">
          <span className="tag ok"><span className="d" />Activo</span>
          <button className="btn" onClick={onEdit}><Ico.Route />Configurar rutas</button>
          <button className="btn" onClick={onEdit}><Ico.Tag />Cargos directos</button>
          <button className="btn btn-primary" onClick={onEdit}><Ico.Edit />Editar</button>
        </div>
      </div>

      <div className="status-banner">
        <span className="ok-dot"><Ico.Check /></span>
        <div>
          <strong>Producto válido.</strong> Listo para cotizar — todos los pasos requeridos están configurados.
        </div>
        <span className="last">Última validación · hace 12 minutos</span>
      </div>

      <div className="stat-row">
        <div className="stat">
          <div className="lbl">¿Cómo se cobra?</div>
          <div className="val">Por unidad</div>
          <div className="sub">Multiplicador: <code style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>caras</code></div>
        </div>
        <div className="stat">
          <div className="lbl">Manejo de medidas</div>
          <div className="val">Medida fija</div>
          <div className="sub">90 × 50 mm · no editable al cotizar</div>
        </div>
        <div className="stat">
          <div className="lbl">Rutas alternativas</div>
          <div className="val">1 ruta</div>
          <div className="sub">Standard <span className="tag" style={{ marginLeft: 4, padding: "0 6px", fontSize: 10.5 }}>preferida</span></div>
        </div>
      </div>

      <div className="route-card">
        <div className="head">
          <h3>Ruta de producción · Standard</h3>
          <span className="preferred">preferida</span>
          <span className="code">RUTA-TARJETA-DIGITAL-STD · v1</span>
          <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
            <button className="btn">Ver como tabla</button>
            <button className="btn" onClick={onEdit}><Ico.Sliders />Editar pasos</button>
          </div>
        </div>

        <div className="graph">
          {STEPS_STANDARD.map((s) => (
            <div key={s.idx} className={`gnode ${s.done ? "done" : ""} ${s.optional ? "optional" : ""}`}>
              <div className="dot">{s.idx}</div>
              <div className="ttl">{s.name}</div>
              <div className="sub">{s.machine}</div>
            </div>
          ))}
        </div>

        <div style={{ paddingTop: 6, marginTop: 8, borderTop: "1px solid var(--hairline)" }}>
          {STEPS_STANDARD.map((s) => (
            <div key={s.idx} className={`step ${s.done ? "done" : ""}`}>
              <span className="idx">{s.idx}</span>
              <div className="info">
                <div className="ttl">{s.name} {s.optional && <span className="tag muted" style={{ marginLeft: 6, fontSize: 10.5 }}>opcional</span>}</div>
                <div className="sub">{s.note}</div>
              </div>
              <div className="meta">
                <span className="machine">{s.machine}</span>
                <Ico.Arrow />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// Generic "Coming soon" page for unscoped nav items
function Placeholder({ title }) {
  return (
    <>
      <div className="page-head">
        <div className="title-block">
          <h1>{title}</h1>
          <div className="sub">Esta sección no es parte del rediseño actual.</div>
        </div>
      </div>
      <div className="empty">
        <svg className="graph-deco" viewBox="0 0 220 120" fill="none">
          <g stroke="var(--border-strong)" strokeWidth="1.5">
            <path d="M30 90 L80 30" /><path d="M80 30 L150 60" />
            <path d="M150 60 L195 30" /><path d="M150 60 L190 95" />
            <path d="M30 90 L100 95" /><path d="M100 95 L150 60" />
          </g>
          <g fill="var(--surface)" stroke="var(--ink)" strokeWidth="1.5">
            <circle cx="30" cy="90" r="5" /><circle cx="80" cy="30" r="5" />
            <circle cx="150" cy="60" r="6" fill="var(--ink)" />
            <circle cx="195" cy="30" r="5" /><circle cx="190" cy="95" r="5" />
            <circle cx="100" cy="95" r="5" />
          </g>
        </svg>
        <div>Pantalla todavía con el diseño anterior — pasamos por acá pronto.</div>
      </div>
    </>
  );
}

Object.assign(window, { Detail, Placeholder });

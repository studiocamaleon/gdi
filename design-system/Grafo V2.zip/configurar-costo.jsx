// Configurar costo — sheet wizard with 5 steps (Ajustes / Recursos / Costos / Capacidad / Resultado)

const COSTO_STEPS = [
  { key: "ajustes", label: "1. Ajustes" },
  { key: "recursos", label: "2. Recursos" },
  { key: "costos", label: "3. Costos" },
  { key: "capacidad", label: "4. Capacidad" },
  { key: "resultado", label: "5. Resultado" },
];

const CENTROS_DETAIL = {
  "Barniz UV tercerizado": { code: "TER-001", area: "Terminacion", planta: "Planta principal", clasificacion: "Tercerizado", sugerencia: "Unidad", sugSub: "según el tipo actual del centro" },
  "CTP principal": { code: "PRE-001", area: "Preprensa", planta: "Planta principal", clasificacion: "Productivo", sugerencia: "Hora hombre", sugSub: "preprensa suele medirse así" },
  "Diseño grafico e Impresion Laser": { code: "IMP-001", area: "Impresion", planta: "Planta principal", clasificacion: "Productivo", sugerencia: "Hora máquina", sugSub: "impresión digital" },
};

function ConfigurarCostoSheet({ centro, onClose }) {
  const [step, setStep] = React.useState("ajustes");
  const info = CENTROS_DETAIL[centro] || CENTROS_DETAIL["Barniz UV tercerizado"];
  const stepIdx = COSTO_STEPS.findIndex(s => s.key === step);

  const goPrev = () => stepIdx > 0 && setStep(COSTO_STEPS[stepIdx - 1].key);
  const goNext = () => stepIdx < COSTO_STEPS.length - 1 && setStep(COSTO_STEPS[stepIdx + 1].key);

  return (
    <>
      <div className="sheet-backdrop" onClick={onClose} />
      <div className="sheet">
        <div className="sheet-head">
          <div className="body">
            <h2>Configurar costo de {centro}</h2>
            <div className="sub">
              Vamos a ayudarte a estimar el costo del sector <strong style={{ color: "var(--ink)", fontWeight: 500, fontFamily: "var(--font-mono)" }}>{info.code}</strong> para un mes de vigencia concreto, sin pedirte que pienses como contador.
            </div>
          </div>
          <button className="close" onClick={onClose}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 6 12 12M18 6 6 18"/></svg>
          </button>
        </div>

        <div className="sheet-body">
          <div className="mes-row">
            <div className="field">
              <label>Mes de vigencia <Tooltip /></label>
              <input type="month" defaultValue="2026-05" />
            </div>
            <button className="btn" style={{ height: 36 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V6a2 2 0 0 1 2-2h10"/></svg>
              Copiar mes anterior
            </button>
            <span className="active-badge">Activo 05/2026</span>
          </div>

          <div className="costo-tabs">
            {COSTO_STEPS.map(s => (
              <button key={s.key} className={`costo-tab ${s.key === step ? "active" : ""}`} onClick={() => setStep(s.key)}>
                {s.label}
              </button>
            ))}
          </div>

          {step === "ajustes" && <CostoAjustes info={info} centro={centro} />}
          {step === "recursos" && <CostoRecursos />}
          {step === "costos" && <CostoCostos />}
          {step === "capacidad" && <CostoCapacidad />}
          {step === "resultado" && <CostoResultado />}
        </div>

        <div className="sheet-foot">
          {stepIdx > 0 && <button className="btn" onClick={goPrev}><Ico.Back />Paso anterior</button>}
          {stepIdx < COSTO_STEPS.length - 1 && <button className="btn btn-primary" onClick={goNext}>Siguiente paso<Ico.Arrow /></button>}
          <span style={{ flex: 1 }} />
          <button className="btn"><Ico.Save />Guardar borrador</button>
          <button className="btn btn-primary"><Ico.Check />Publicar tarifa</button>
          <button className="btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
            Recalcular
          </button>
        </div>
      </div>
    </>
  );
}

function CostoAjustes({ info, centro }) {
  return (
    <>
      <div className="wiz-section-head">
        <div className="body">
          <h2>Ajustes de costeo</h2>
          <div className="helptext">Acá solo ajustás cómo querés usar este centro en el costeo. La identidad del centro ya viene definida desde la pantalla anterior.</div>
        </div>
      </div>

      <div className="recap">
        <div className="col">
          <div className="lbl">Centro</div>
          <div className="v" style={{ fontFamily: "var(--font-mono)" }}>{info.code}</div>
          <div className="vsub">{centro}</div>
        </div>
        <div className="col">
          <div className="lbl">Ubicación</div>
          <div className="v">{info.planta}</div>
          <div className="vsub">{info.area}</div>
        </div>
        <div className="col">
          <div className="lbl">Clasificación</div>
          <div className="v">{info.clasificacion}</div>
          <div className="vsub">{info.clasificacion}</div>
        </div>
        <div className="col">
          <div className="lbl">Sugerencia</div>
          <div className="v">{info.sugerencia}</div>
          <div className="vsub">{info.sugSub}</div>
        </div>
      </div>

      <div className="wiz-cols" style={{ marginBottom: 14 }}>
        <div className="field">
          <label>Cómo querés medirlo</label>
          <div className="control select" style={{ height: 36 }}><span>{info.sugerencia}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          <span className="help">Ejemplo: impresión suele trabajar mejor con hora máquina; preprensa, con hora hombre.</span>
        </div>
        <div className="field">
          <label>Tipo de costo</label>
          <div className="control select" style={{ height: 36 }}><span>Reparto</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          <span className="help">Directo: imputa al producto. Reparto: distribuye sobre otros centros.</span>
        </div>
      </div>
      <div className="field">
        <label>Descripción útil</label>
        <textarea defaultValue={centro === "Barniz UV tercerizado" ? "Proveedor externo para procesos especiales" : "Comentarios operativos del costeo"} rows={3} />
      </div>
    </>
  );
}

function CostoRecursos() {
  return (
    <>
      <div className="wiz-section-head">
        <div className="body">
          <h2>¿Qué usa este sector para trabajar?</h2>
          <div className="helptext">Acá definís los recursos del mes. Las personas llevan porcentaje de dedicación y el sistema después toma eso para pedir su costo del centro sin duplicar asignaciones.</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>
        <button className="btn"><Ico.Plus />Agregar Persona</button>
        <button className="btn"><Ico.Plus />Agregar Maquinaria</button>
        <button className="btn"><Ico.Plus />Agregar Gasto general</button>
        <button className="btn"><Ico.Plus />Agregar Activo fijo</button>
      </div>

      <div className="section-empty">
        <div className="ttl">Sin recursos cargados</div>
        <div className="sub">Empezá por las personas, maquinaria, gastos generales o activos fijos.</div>
      </div>
    </>
  );
}

function CostoCostos() {
  return (
    <>
      <div className="wiz-section-head">
        <div className="body">
          <h2>¿Cuánto te cuesta por mes mantenerlo funcionando?</h2>
          <div className="helptext">El sistema armó esta pantalla según los recursos del paso 2. Los importes se cargan en ARS y se recalculan solos cuando cambia la dedicación de las personas o los datos de una máquina.</div>
        </div>
      </div>

      <div className="acc-info" style={{ marginBottom: 14 }}>
        Todos los valores monetarios se cargan en <strong style={{ color: "var(--ink)" }}>ARS</strong>.
      </div>

      <div className="section-empty">
        <div className="ttl">Sin costos cargados</div>
        <div className="sub">Empezá por los recursos del paso 2. Después podés sumar energía, alquiler u otros costos del centro.</div>
      </div>
    </>
  );
}

function CostoCapacidad() {
  return (
    <>
      <div className="wiz-section-head">
        <div className="body">
          <h2>¿Cuántas horas reales trabaja al mes?</h2>
          <div className="helptext">La capacidad práctica se calcula automáticamente según los recursos del paso 2. Podés ajustar días/horas base o usar una capacidad manual.</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 16 }}>
        <div className="field">
          <label>Días por mes</label>
          <input type="number" defaultValue="22" />
          <span className="help">Ejemplo: 22</span>
        </div>
        <div className="field">
          <label>Horas por día</label>
          <input type="number" defaultValue="8" />
          <span className="help">Ejemplo: 8</span>
        </div>
        <div className="field">
          <label>Capacidad manual</label>
          <input type="number" placeholder="—" />
          <span className="help">Opcional: usala si ya conocés la capacidad real del mes.</span>
        </div>
      </div>

      <div className="kpi-strip">
        <div className="kpi">
          <div className="lbl">Horas teóricas</div>
          <div className="v">176</div>
        </div>
        <div className="kpi">
          <div className="lbl">Capacidad automática</div>
          <div className="v">176</div>
        </div>
        <div className="kpi">
          <div className="lbl">Horas prácticas</div>
          <div className="v">176</div>
        </div>
      </div>

      <div className="kpi" style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: "var(--r-2)", padding: "14px 16px", maxWidth: 320 }}>
        <div className="lbl" style={{ fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--muted)", fontWeight: 500, marginBottom: 4 }}>Unidad elegida</div>
        <div style={{ fontSize: 20, fontWeight: 600 }}>Unidad</div>
      </div>
    </>
  );
}

function CostoResultado() {
  return (
    <>
      <div className="wiz-section-head">
        <div className="body">
          <h2>Resultado estimado</h2>
          <div className="helptext">Este resumen te muestra qué tarifa podría usar el sistema si publicás este período.</div>
        </div>
      </div>

      <div className="kpi-strip cols-4" style={{ marginBottom: 12 }}>
        <div className="kpi">
          <div className="lbl">Costo mensual directo</div>
          <div className="v"><span className="currency">$</span>0</div>
        </div>
        <div className="kpi">
          <div className="lbl">Absorbido por reparto</div>
          <div className="v"><span className="currency">$</span>0</div>
        </div>
        <div className="kpi">
          <div className="lbl">Costo mensual total</div>
          <div className="v"><span className="currency">$</span>0</div>
        </div>
        <div className="kpi">
          <div className="lbl">Capacidad real</div>
          <div className="v">176</div>
        </div>
      </div>

      <div className="kpi" style={{ background: "var(--surface)", border: "1px solid var(--ink)", borderRadius: "var(--r-2)", padding: "16px 18px", marginBottom: 18, maxWidth: 380 }}>
        <div className="lbl" style={{ fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--muted)", fontWeight: 500, marginBottom: 4 }}>Tarifa calculada</div>
        <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: "-0.015em", fontVariantNumeric: "tabular-nums" }}>
          <span style={{ color: "var(--muted)", fontWeight: 400, marginRight: 4 }}>$</span>0
        </div>
        <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>por Unidad</div>
      </div>

      <div className="wiz-section-head" style={{ marginBottom: 8 }}>
        <div className="body">
          <h2 style={{ fontSize: 14 }}>Desglose de reparto absorbido</h2>
          <div className="helptext">Costos trasladados desde centros con imputación por reparto al centro actual.</div>
        </div>
      </div>
      <div className="acc-info" style={{ marginBottom: 18 }}>
        Este centro no absorbió reparto en el período seleccionado.
      </div>

      <div className="wiz-section-head" style={{ marginBottom: 8 }}>
        <div className="body">
          <h2 style={{ fontSize: 14 }}>Checklist</h2>
          <div className="helptext">Verificación rápida de lo necesario para guardar y publicar este período.</div>
        </div>
      </div>
      <div className="check-list">
        <div className="ci">
          <span className="dot"><Ico.Check /></span>
          <div className="lbl-block">
            <div className="nm">Unidad de costeo definida</div>
            <div className="sub">El centro ya sabe si se va a medir por hora, unidad, m² o kg.</div>
          </div>
        </div>
        <div className="ci warn">
          <span className="dot">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 8v5"/><circle cx="12" cy="17" r=".5" fill="currentColor"/></svg>
          </span>
          <div className="lbl-block">
            <div className="nm">Recursos del sector cargados</div>
            <div className="sub">Hay al menos una persona, máquina, gasto general o activo fijo activo para este mes.</div>
          </div>
        </div>
        <div className="ci">
          <span className="dot"><Ico.Check /></span>
          <div className="lbl-block">
            <div className="nm">Dedicación de personas validada</div>
            <div className="sub">Las personas asignadas tienen porcentaje válido y no superan la disponibilidad del mes.</div>
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { ConfigurarCostoSheet });

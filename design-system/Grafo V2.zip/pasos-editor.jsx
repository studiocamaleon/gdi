// Pasos editor — full-screen, redesigned for hierarchy.
// Layout: left stepper (28% width-ish) + main editor focused on ONE step at a time.
// Each step's editor uses collapsible SECTIONS instead of the original three-tab Básico/Materiales/Avanzado
// that had a duplicated right-side summary per step.

const PASOS = [
  {
    key: "diseno",
    name: "Diseño gráfico",
    activation: "Opcional",
    timing: "Tiempo fijo",
    machine: "CTP principal",
    profile: null,
    materials: [],
    advanced: { tiempoFijo: "5 min" },
    status: "optional",
  },
  {
    key: "preprensa",
    name: "Pre-prensa / armado de imposición",
    activation: "Obligatorio",
    timing: "Tiempo fijo",
    machine: "CTP principal",
    profile: null,
    materials: [],
    advanced: { tiempoFijo: "10 min (override)" },
    status: "done",
  },
  {
    key: "impresion",
    name: "Impresión por hoja",
    activation: "Obligatorio",
    timing: "Productividad de la máquina y perfil",
    machine: "Ricoh PRO C5100",
    profile: "Papel grueso simple faz",
    materials: [{ name: "Sustrato principal", mode: "Material fijo", value: "OPALINA-300-65X45" }],
    advanced: { quantity: "Hereda del paso anterior", multipliers: ["caras"] },
    status: "done",
  },
  {
    key: "laminado",
    name: "Laminado",
    activation: "Opcional",
    timing: "Productividad de la máquina y perfil",
    machine: "Laminadora BOPP rollo",
    profile: "Estándar",
    materials: [{ name: "Film BOPP", mode: "Material fijo", value: "BOPP-MATE-25MIC" }],
    advanced: {},
    status: "optional",
  },
  {
    key: "corte",
    name: "Guillotina / corte",
    activation: "Obligatorio",
    timing: "Tiempo fijo",
    machine: "Polar 76",
    profile: null,
    materials: [],
    advanced: { tiempoFijo: "8 min" },
    status: "done",
  },
  {
    key: "empaque",
    name: "Empaque",
    activation: "Obligatorio",
    timing: "Tiempo fijo",
    machine: "Mesa de empaque",
    profile: null,
    materials: [{ name: "Caja", mode: "Cantidad por paquete", value: "CAJA-100" }],
    advanced: { tiempoFijo: "3 min" },
    status: "done",
  },
  {
    key: "qa",
    name: "Despacho / QA",
    activation: "Obligatorio",
    timing: "Tiempo fijo",
    machine: "Mesa final",
    profile: null,
    materials: [],
    advanced: { tiempoFijo: "2 min" },
    status: "done",
  },
];

// Collapsible section block
function Section({ num, title, hint, defaultOpen = true, children }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div className={`section-block ${open ? "open" : "closed"}`}>
      <div className="sb-head" onClick={() => setOpen(!open)}>
        <span className="num">{num}</span>
        <span className="ttl">{title}</span>
        {hint && <span className="hint">{hint}</span>}
        <span className="chev"><Ico.Chev /></span>
      </div>
      <div className="sb-body">{children}</div>
    </div>
  );
}

function PasosEditor({ onBack }) {
  const [activeKey, setActiveKey] = React.useState("impresion");
  const active = PASOS.find((p) => p.key === activeKey) || PASOS[0];
  const activeIdx = PASOS.findIndex((p) => p.key === activeKey);

  const goPrev = () => {
    if (activeIdx > 0) setActiveKey(PASOS[activeIdx - 1].key);
  };
  const goNext = () => {
    if (activeIdx < PASOS.length - 1) setActiveKey(PASOS[activeIdx + 1].key);
  };

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      if (e.key === "ArrowDown" || e.key === "j") goNext();
      else if (e.key === "ArrowUp" || e.key === "k") goPrev();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const doneCount = PASOS.filter((p) => p.status === "done").length;
  const total = PASOS.filter((p) => p.status !== "optional" || p.status === "done").length;

  return (
    <div className="editor-shell">
      {/* LEFT — stepper */}
      <aside className="editor-side">
        <div className="side-head">
          <div onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12, marginBottom: 8, cursor: "pointer" }}>
            <Ico.Back /> Volver a rutas
          </div>
          <div className="route">
            <span>★</span> Standard
          </div>
          <div className="sub">RUTA-TARJETA-DIGITAL-STD · v1</div>
        </div>
        <div className="side-progress">
          <span>{doneCount}/{PASOS.length} pasos</span>
          <div className="bar"><span style={{ width: `${(doneCount / PASOS.length) * 100}%` }} /></div>
        </div>
        <div className="pasos">
          {PASOS.map((p, i) => (
            <div
              key={p.key}
              className={`paso-item ${p.status === "done" ? "done" : ""} ${p.status === "optional" ? "optional" : ""} ${p.key === activeKey ? "active" : ""}`}
              onClick={() => setActiveKey(p.key)}
            >
              <span className="ix">{p.status === "done" ? <Ico.Check /> : i + 1}</span>
              <div className="body">
                <div className="ttl">{p.name}</div>
                <div className="sub">{p.machine}</div>
              </div>
              <div className="status">{p.status === "done" ? "✓" : p.status === "optional" ? "Opt" : "·"}</div>
            </div>
          ))}
        </div>
        <div style={{ padding: "12px 14px", borderTop: "1px solid var(--hairline)", color: "var(--muted)", fontSize: 11.5 }}>
          <span className="kbd-hint">Navegar pasos con <span className="k">↑</span> <span className="k">↓</span></span>
        </div>
      </aside>

      {/* MAIN editor */}
      <div className="editor-main">
        {/* mini graph: brand metaphor, also helps orient */}
        <div className="mini-graph">
          {PASOS.map((p, i) => (
            <React.Fragment key={p.key}>
              <div
                className={`mn ${p.status === "done" ? "done" : ""} ${p.status === "optional" ? "optional" : ""} ${p.key === activeKey ? "active" : ""}`}
                onClick={() => setActiveKey(p.key)}
                title={p.name}
              >
                <span className="d">{p.status === "done" ? "✓" : i + 1}</span>
                <span className="lb">{p.name.split(" ")[0]}</span>
              </div>
              {i < PASOS.length - 1 && (
                <div className={`edge ${p.status === "done" && PASOS[i + 1].status === "done" ? "done" : ""}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Step head */}
        <div className="step-head">
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "var(--muted)", fontFamily: "var(--font-mono)", fontSize: 12 }}>
                Paso {activeIdx + 1} de {PASOS.length}
              </span>
              <span className={`tag ${active.status === "done" ? "ok" : ""}`}>
                <span className="d" />{active.status === "done" ? "Configurado" : active.status === "optional" ? "Opcional" : "Pendiente"}
              </span>
              <span className="tag" style={{ background: "var(--surface-2)" }}>{active.activation}</span>
            </div>
            <h1 style={{ marginTop: 6 }}>{active.name}</h1>
            <div className="sub">
              {active.machine && <>Máquina: <strong style={{ color: "var(--ink)", fontWeight: 500 }}>{active.machine}</strong>{active.profile && <> · perfil {active.profile}</>}</>}
            </div>
          </div>
          <div className="pill-row">
            <button className="btn" onClick={goPrev} disabled={activeIdx === 0}><Ico.Back /></button>
            <button className="btn" onClick={goNext} disabled={activeIdx === PASOS.length - 1}><Ico.Arrow /></button>
          </div>
        </div>

        {/* Sections */}
        <Section num="01" title="Activación" hint="Cuándo se ejecuta este paso al cotizar">
          <div className="wiz-grid">
            <div className="field">
              <label>Cuándo se ejecuta</label>
              <div className="segmented">
                <button className={active.activation === "Obligatorio" ? "on" : ""}>Obligatorio</button>
                <button className={active.activation === "Opcional" ? "on" : ""}>Opcional</button>
                <button>Desactivado</button>
              </div>
              <span className="help">Los pasos opcionales no se ejecutan a menos que el comercial los active.</span>
            </div>
            <div className="field">
              <label>Multiplicadores</label>
              <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                <span className="tag mono">caras</span>
                <span className="tag muted" style={{ cursor: "pointer", borderStyle: "dashed" }}>+ Agregar</span>
              </div>
              <span className="help">Variables que multiplican el costo del paso (ej: caras, colores).</span>
            </div>
          </div>
        </Section>

        <Section num="02" title="Tiempo y costo">
          <div className="wiz-grid">
            <div className="field">
              <label>¿Cómo se calcula el tiempo?</label>
              <div className="control select"><span>{active.timing}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
            <div className="field">
              <label>Centro de costo</label>
              <div className="control select"><span>CTP principal</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
            {active.timing === "Tiempo fijo" && (
              <div className="field">
                <label>Tiempo fijo override <span className="hint">opcional</span></label>
                <input type="text" defaultValue={active.advanced?.tiempoFijo || ""} placeholder="ej: 10 min" />
              </div>
            )}
            <div className="field">
              <label>¿De dónde sale la cantidad?</label>
              <div className="control select"><span>Hereda del paso anterior</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
          </div>
        </Section>

        {active.machine && (
          <Section num="03" title="Máquina y perfil">
            <div className="wiz-grid">
              <div className="field">
                <label>Máquina principal <span className="req">*</span></label>
                <div className="control select"><span>{active.machine}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
              </div>
              {active.profile && (
                <div className="field">
                  <label>Perfil de la máquina</label>
                  <div className="control select"><span>{active.profile}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
                </div>
              )}
            </div>
          </Section>
        )}

        <Section
          num={active.machine ? "04" : "03"}
          title="Materiales"
          hint={active.materials.length === 0 ? "Sin materiales en este paso" : `${active.materials.length} slot(s)`}
          defaultOpen={active.materials.length > 0}
        >
          {active.materials.length === 0 ? (
            <div className="empty" style={{ padding: "12px 0 8px", margin: 0, textAlign: "left" }}>
              <span style={{ color: "var(--muted)", fontSize: 12 }}>Este paso no requiere materiales. </span>
              <span style={{ color: "var(--ink)", fontSize: 12, cursor: "pointer", textDecoration: "underline" }}>Agregar slot</span>
            </div>
          ) : (
            <>
              {active.materials.map((m) => (
                <div className="material-slot" key={m.name}>
                  <div>
                    <div className="slot-name">{m.name}</div>
                    <div className="slot-sub">{m.value}</div>
                  </div>
                  <div className="slot-mode">{m.mode}</div>
                  <div style={{ display: "flex", gap: 4 }}>
                    <span className="slot-action">Cambiar</span>
                    <span className="slot-action">Quitar</span>
                  </div>
                </div>
              ))}
              <div style={{ marginTop: 10, fontSize: 12, color: "var(--ink)", cursor: "pointer" }}>+ Agregar slot</div>
            </>
          )}
        </Section>

        <Section num={active.machine ? "05" : "04"} title="Avanzado" hint="Overrides y notas internas" defaultOpen={false}>
          <div className="wiz-grid">
            <div className="field">
              <label>Comentarios internos</label>
              <textarea placeholder="No visible para el comercial. Ej: si el cliente trae diseño, este paso se omite." />
            </div>
            <div className="field">
              <label>Tags</label>
              <input type="text" placeholder="impresion-digital, color-completo" />
            </div>
          </div>
        </Section>

        <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, color: "var(--muted)", fontSize: 12 }}>
          <span className="dot" style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--ok)", display: "inline-block" }} />
          Los cambios se guardan automáticamente.
          <span style={{ flex: 1 }} />
          <button className="btn">Duplicar paso</button>
          <button className="btn">Restablecer</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PasosEditor, PASOS });

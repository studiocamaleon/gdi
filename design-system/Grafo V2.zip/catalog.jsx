// Catalog page — context for the rebrand. Clicking a row navigates to detail.

const PRODUCTS = [
  {
    code: "RIGIDO-CUSTOM",
    name: "Rígido impreso custom (señalética/letras)",
    desc: "Producto genérico para señalética y letras corpóreas en rígidos impresos",
    cobro: "Por unidad",
    medidas: "El comercial ingresa medidas",
    medidasWarm: true,
    routes: [{ name: "Standard" }],
    estado: "Activo",
  },
  {
    code: "TALON-DUPL-A4",
    name: "Talonario duplicado A4",
    desc: "Talonario A4 duplicado en papel autocopiativo (CB+CFB)",
    cobro: "Por unidad",
    medidas: "Medida fija del producto",
    routes: [{ name: "Emblocado" }, { name: "Abrochado" }],
    estado: "Activo",
  },
  {
    code: "TARJ-PREMIUM-300",
    name: "Tarjetas de Visita Premium 300gr",
    desc: "Tarjetas de visita en papel opalina 300gr, 9×5cm",
    cobro: "Por unidad",
    medidas: "Medida fija del producto",
    routes: [{ name: "Standard" }],
    estado: "Activo",
    primary: true,
  },
  {
    code: "VINILO-BLANCO-IMP",
    name: "Vinilo blanco impreso",
    desc: "Vinilo adhesivo blanco impreso, gran formato, medidas libres",
    cobro: "Por metro cuadrado",
    medidas: "El comercial ingresa medidas",
    medidasWarm: true,
    routes: [{ name: "Standard" }],
    estado: "Activo",
  },
];

function Catalog({ onOpenProduct }) {
  const [query, setQuery] = React.useState("");

  const filtered = PRODUCTS.filter(p =>
    !query ||
    p.code.toLowerCase().includes(query.toLowerCase()) ||
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    p.desc.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <div className="page-head">
        <div className="title-block">
          <h1>Catálogo de productos</h1>
          <div className="sub">4 productos cargados en el modelo universal por pasos.</div>
        </div>
        <button className="btn">Importar</button>
        <button className="btn btn-primary">
          <Ico.Plus />
          Nuevo producto
        </button>
      </div>

      <div className="toolbar">
        <div className="search">
          <Ico.Search />
          <input
            placeholder="Buscar por código, nombre o descripción…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <span className="kbd">/</span>
        </div>
        <div className="select"><span className="lbl">Cobro</span> todos <Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
        <div className="select"><span className="lbl">Estado</span> todos <Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
      </div>

      <div className="card">
        <div className="card-head">
          <span className="title">Productos</span>
          <span className="count">{filtered.length} de {PRODUCTS.length}</span>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8, color: "var(--muted)" }}>
            <span style={{ fontSize: 12 }}>Ordenar por</span>
            <div className="select" style={{ height: 28 }}>Recientes <Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
        </div>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 180 }}>Código</th>
              <th>Nombre</th>
              <th>¿Cómo se cobra?</th>
              <th>Manejo de medidas</th>
              <th>Rutas</th>
              <th>Estado</th>
              <th className="right" style={{ width: 100 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => (
              <tr key={p.code} onClick={() => onOpenProduct(p.code)}>
                <td><span className="code">{p.code}</span></td>
                <td>
                  <div className="name">{p.name}</div>
                  <div className="desc">{p.desc}</div>
                </td>
                <td><span className="tag muted"><span className="d" />{p.cobro}</span></td>
                <td>
                  <span className={`tag ${p.medidasWarm ? "warm" : ""}`}>
                    <span className="d" />{p.medidas}
                  </span>
                </td>
                <td>
                  <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                    {p.routes.map(r => (
                      <span key={r.name} className="tag route"><Ico.Route />{r.name}</span>
                    ))}
                  </div>
                </td>
                <td><span className="tag ok"><span className="d" />{p.estado}</span></td>
                <td className="right">
                  <span className="actions">
                    <a onClick={(e) => { e.stopPropagation(); onOpenProduct(p.code); }}>Ver detalle</a>
                    <Ico.Arrow />
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 14, color: "var(--muted)", fontSize: 12, display: "flex", justifyContent: "space-between" }}>
        <span>Mostrando {filtered.length} de {PRODUCTS.length} productos</span>
        <span>Última sincronización · hace 2 min</span>
      </div>
    </>
  );
}

Object.assign(window, { Catalog });

// Wizard — Edición de producto
// 5 tabs: Identidad, Rutas, Configurar pasos, Cargos, Pricing
// Each tab matches the actual production layout.

const WIZ_STEPS = [
  { key: "identidad", label: "Identidad", icon: "Tag", status: "Completo" },
  { key: "rutas", label: "Rutas", icon: "Route", status: "Completo" },
  { key: "pasos", label: "Configurar pasos", icon: "Sliders", status: "Completo" },
  { key: "cargos", label: "Cargos", icon: "Coin", status: "Opcional", optional: true },
  { key: "precio", label: "Pricing", icon: "Coin", status: "Completo" },
];

// ─────────────────────────── Wizard tabs (5 wide cards)
function WizardTabs({ step, onChange }) {
  return (
    <div className="wiz-tabs" role="tablist">
      {WIZ_STEPS.map((s) => {
        const Icon = Ico[s.icon];
        const active = s.key === step;
        return (
          <button
            key={s.key}
            role="tab"
            aria-selected={active}
            className={`wiz-tab ${active ? "active" : ""} ${s.optional ? "optional" : ""}`}
            onClick={() => onChange(s.key)}
          >
            <span className="ico"><Icon /></span>
            <span className="lbl">{s.label}</span>
            <span className="status">
              {s.optional ? null : <Ico.Check />}
              {s.status}
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────────────── Top of wizard: back link + title + status
function WizardHeader({ onBack }) {
  return (
    <>
      <a className="back-link" onClick={onBack}><Ico.Back /> Volver al catálogo</a>
      <div className="detail-head">
        <div className="title-block">
          <h1 style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
            Tarjetas de Visita Premium 300gr
            <span className="tag ok"><span className="d" />Activo</span>
          </h1>
          <div className="meta">
            <span className="code">TARJ-PREMIUM-300</span>
          </div>
          <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 6 }}>
            Tarjetas de visita en papel opalina 300gr, 9×5cm
          </div>
        </div>
      </div>
      <div className="wiz-status">
        <span className="ok-dot"><Ico.Check /></span>
        <div><strong>Producto válido. </strong>Listo para cotizar.</div>
        <span className="refresh" title="Revalidar">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>
          </svg>
        </span>
      </div>
    </>
  );
}

// ─────────────────────────── Step 1: Identidad
function StepIdentidad() {
  const [active, setActive] = React.useState(true);
  const [cobro, setCobro] = React.useState("unidad");
  const [medidas, setMedidas] = React.useState("fija");

  return (
    <div className="wiz-cols">
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Identidad</h2>
            <div className="helptext">Cómo se llama y se reconoce el producto en el catálogo.</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="field">
            <label>Código</label>
            <input type="text" className="locked" value="TARJ-PREMIUM-300" readOnly />
            <span className="help">El código no se puede modificar.</span>
          </div>
          <div className="field">
            <label>Nombre <span className="req">*</span></label>
            <input type="text" defaultValue="Tarjetas de Visita Premium 300gr" />
          </div>
          <div className="field">
            <label>Descripción</label>
            <textarea defaultValue="Tarjetas de visita en papel opalina 300gr, 9×5cm" />
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 6, borderTop: "1px solid var(--hairline)" }}>
            <div>
              <div style={{ fontWeight: 500, fontSize: 13 }}>Activo</div>
              <div style={{ fontSize: 11.5, color: "var(--muted)" }}>
                Si está inactivo no aparece en el cotizador.
              </div>
            </div>
            <div className={`toggle ${active ? "on" : ""}`} onClick={() => setActive(!active)}>
              <span className="switch" />
            </div>
          </div>
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Comercial y medidas</h2>
            <div className="helptext">Cómo se cobra y cómo se manejan las medidas al cotizar.</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="field">
            <label>¿Cómo se cobra? <Tooltip /></label>
            <div className="segmented" style={{ width: "100%" }}>
              <button className={cobro === "unidad" ? "on" : ""} onClick={() => setCobro("unidad")} style={{ flex: 1 }}>Por unidad</button>
              <button className={cobro === "m2" ? "on" : ""} onClick={() => setCobro("m2")} style={{ flex: 1 }}>Por m²</button>
              <button className={cobro === "ml" ? "on" : ""} onClick={() => setCobro("ml")} style={{ flex: 1 }}>Por metro lineal</button>
            </div>
          </div>
          <div className="field">
            <label>Manejo de medidas <Tooltip /></label>
            <div className="segmented" style={{ width: "100%" }}>
              <button className={medidas === "fija" ? "on" : ""} onClick={() => setMedidas("fija")} style={{ flex: 1 }}>Medida fija del producto</button>
              <button className={medidas === "comercial" ? "on" : ""} onClick={() => setMedidas("comercial")} style={{ flex: 1 }}>El comercial ingresa</button>
            </div>
          </div>
          {medidas === "fija" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div className="field">
                <label>Ancho default <span className="hint">mm</span></label>
                <input type="number" defaultValue="90" />
              </div>
              <div className="field">
                <label>Alto default <span className="hint">mm</span></label>
                <input type="number" defaultValue="50" />
              </div>
            </div>
          )}
          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 6 }}>
            <button className="btn btn-primary">
              <Ico.Save /> Guardar identidad
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Tooltip() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", marginLeft: 2, color: "var(--muted-2)" }} title="Más info">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>
    </span>
  );
}

// ─────────────────────────── Step 2: Rutas + Pasos extras inline
function StepRutas({ onOpenRoute }) {
  return (
    <>
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Rutas alternativas</h2>
            <div className="helptext">
              Asociá/quitá rutas reusables a este producto. La ruta preferida es la default al cotizar.
            </div>
          </div>
          <button className="btn btn-primary"><Ico.Plus /> Agregar ruta</button>
        </div>

        <div className="route-tab" onClick={onOpenRoute}>
          <span className="star">★</span>
          <div className="body">
            <div className="ttl">
              Standard <span className="tag ok"><span className="d" />Preferida</span>
            </div>
            <div className="sub" style={{ fontFamily: "var(--font-mono)", fontSize: 11, marginTop: 2 }}>
              RUTA-TARJETA-DIGITAL-STD
            </div>
            <div className="sub" style={{ marginTop: 8 }}>
              <strong style={{ color: "var(--ink)", fontWeight: 500 }}>Ruta:</strong> Tarjeta digital standard · v1
              <span style={{ margin: "0 6px" }}>·</span>
              <strong style={{ color: "var(--ink)", fontWeight: 500 }}>Pasos:</strong> 7 · <span style={{ color: "var(--ok)" }}>Configurados 7/7</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6, alignSelf: "flex-end" }}>
            <button className="btn btn-primary" onClick={(e) => { e.stopPropagation(); onOpenRoute(); }}>
              <Ico.Sliders /> Configurar pasos
            </button>
            <button className="icon-btn" title="Quitar ruta" onClick={(e) => e.stopPropagation()}>
              <Ico.Trash />
            </button>
          </div>
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Pasos extras inline <span style={{ color: "var(--muted)", fontWeight: 400, fontFamily: "var(--font-mono)", fontSize: 12, whiteSpace: "nowrap" }}>(G-F3)</span></h2>
            <div className="helptext">
              Pasos puntuales que solo este producto necesita y no forman parte de la ruta reusable. Útil para casos únicos (instalación especial, terminación a medida).
            </div>
          </div>
        </div>

        <div className="section-empty">
          <div className="ttl">Sin pasos extras</div>
          <div className="sub">Si querés agregar una operación que solo aplica a este producto sin tocar la ruta, agregala acá abajo.</div>
        </div>

        <div style={{ marginTop: 16, padding: 16, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)" }}>
          <div style={{ fontWeight: 500, fontSize: 13, marginBottom: 12 }}>Agregar nuevo paso extra</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div className="field">
              <label>Familia <Tooltip /></label>
              <div className="control select"><span style={{ color: "var(--muted)" }}>Elegí familia</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
            <div className="field">
              <label>¿Cuándo se aplica? <Tooltip /></label>
              <div className="control select"><span>Obligatorio</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
            <div className="field">
              <label>¿Cómo se calcula el tiempo? <Tooltip /></label>
              <div className="control select"><span>Productividad propia del paso</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <button className="btn btn-primary"><Ico.Plus /> Agregar paso extra</button>
          </div>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────── Step 3: Configurar pasos (ruta selector + entry point)
function StepPasos({ onOpenRoute }) {
  return (
    <>
      <div className="ruta-selector">
        <div style={{ flex: 1 }}>
          <div className="lbl">Ruta a configurar</div>
          <div className="help">Cada alternativa mantiene su propia configuración de pasos.</div>
        </div>
        <div className="control select" style={{ width: 280, height: 36 }}>
          <span>★ Standard</span>
          <Ico.Chev style={{ transform: "rotate(90deg)" }} />
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Configurar pasos: Tarjetas de Visita Premium 300gr → Standard</h2>
            <div className="helptext">
              Para cada paso configurás la máquina, perfil, modos y slots de materiales. Los pasos OPCIONALES no se ejecutan a menos que el comercial los active.
            </div>
          </div>
          <button className="btn btn-primary" onClick={onOpenRoute}>
            <Ico.Sliders /> Abrir editor enfocado
          </button>
        </div>

        <div style={{ background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)", padding: "16px 18px" }}>
          <div style={{ fontSize: 12.5, color: "var(--muted)", marginBottom: 12 }}>
            7 pasos · click en cualquiera para editarlo
          </div>
          <div className="graph">
            {[
              { idx: 1, name: "Diseño gráfico", machine: "CTP principal", optional: true, done: true },
              { idx: 2, name: "Pre-prensa", machine: "CTP principal", done: true },
              { idx: 3, name: "Impresión", machine: "Ricoh PRO C5100", done: true },
              { idx: 4, name: "Laminado", machine: "Laminadora BOPP", optional: true, done: true },
              { idx: 5, name: "Guillotina", machine: "Polar 76", done: true },
              { idx: 6, name: "Empaque", machine: "Mesa de empaque", done: true },
              { idx: 7, name: "QA", machine: "Mesa final", done: true },
            ].map((s) => (
              <div key={s.idx} className={`gnode ${s.done ? "done" : ""} ${s.optional ? "optional" : ""}`} onClick={onOpenRoute} style={{ cursor: "pointer" }}>
                <div className="dot">{s.idx}</div>
                <div className="ttl">{s.name}</div>
                <div className="sub">{s.machine}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--border)" }}>
            <div style={{ fontSize: 12, color: "var(--muted)", display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--ok)" }}></span>
              7/7 pasos configurados · todos los obligatorios completos
            </div>
            <button className="btn" onClick={onOpenRoute}>
              Editar pasos enfocado <Ico.Arrow />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────── Step 4: Cargos
function StepCargos() {
  return (
    <div className="wiz-section">
      <div className="wiz-section-head">
        <div className="body">
          <h2>Cargos directos del producto</h2>
          <div className="helptext">
            Cargos a nivel cotización (ej: viático, recargo urgencia). Se ofrecen al comercial al cotizar este producto.
          </div>
        </div>
        <button className="btn btn-primary"><Ico.Plus /> Asociar cargo</button>
      </div>

      <div className="section-empty">
        <div className="ttl">Sin cargos asociados</div>
        <div className="sub">Este producto no tiene cargos directos a nivel cotización. Asociá uno del catálogo si necesitás ofrecer extras al comercial.</div>
        <button className="btn"><Ico.Plus /> Asociar cargo del catálogo</button>
      </div>
    </div>
  );
}

// ─────────────────────────── Step 5: Pricing (NEW)
function StepPricing() {
  const [tramos, setTramos] = React.useState([
    { hasta: 100, margen: 60 },
    { hasta: 200, margen: 50 },
    { hasta: 300, margen: 45 },
    { hasta: 400, margen: 40 },
  ]);
  const [impuestos, setImpuestos] = React.useState({ iibb: true, iva: true });

  const updateTramo = (i, k, v) => {
    setTramos((prev) => prev.map((t, j) => j === i ? { ...t, [k]: Number(v) || 0 } : t));
  };
  const removeTramo = (i) => setTramos((prev) => prev.filter((_, j) => j !== i));
  const addTramo = () => setTramos((prev) => [...prev, { hasta: 0, margen: 30 }]);

  const totalImpuestos = (impuestos.iibb ? 5 : 0) + (impuestos.iva ? 21 : 0);

  return (
    <>
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Método de cálculo</h2>
            <div className="helptext">Cómo se calcula el precio de venta a partir del costo del motor.</div>
          </div>
        </div>
        <div className="field">
          <label>Método de cálculo <Tooltip /></label>
          <div className="control select" style={{ height: 36 }}>
            <span>Margen variable por cantidad (escalonado)</span>
            <Ico.Chev style={{ transform: "rotate(90deg)" }} />
          </div>
          <span className="help">Margen distinto según el rango de cantidad del pedido (descuento por volumen).</span>
        </div>

        <div style={{ marginTop: 18, padding: 16, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ fontWeight: 600, fontSize: 13.5 }}>Tramos</div>
            <button className="btn" onClick={addTramo}><Ico.Plus /> Agregar tramo</button>
          </div>

          {tramos.map((t, i) => (
            <div className="tramo-row" key={i}>
              <span className="ix">#{i + 1}</span>
              <span className="lbl">Hasta</span>
              <input type="number" value={t.hasta} onChange={(e) => updateTramo(i, "hasta", e.target.value)} />
              <span className="lbl">unidades →</span>
              <input type="number" value={t.margen} onChange={(e) => updateTramo(i, "margen", e.target.value)} />
              <span className="lbl">% margen</span>
              <button className="x" onClick={() => removeTramo(i)} title="Quitar tramo">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m6 6 12 12M18 6 6 18"/></svg>
              </button>
            </div>
          ))}
          <div style={{ marginTop: 10, fontSize: 11.5, color: "var(--muted)" }}>
            Cada tramo aplica si la cantidad es ≤ al límite. El último tramo cubre cantidades mayores.
          </div>
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Impuestos</h2>
            <div className="helptext">Esquemas impositivos del catálogo del tenant que se aplican al cotizar este producto.</div>
          </div>
          <button className="btn"><Ico.External /> Administrar catálogo</button>
        </div>

        <div className="checkpill-row">
          <div className={`checkpill ${impuestos.iibb ? "on" : ""}`} onClick={() => setImpuestos((p) => ({ ...p, iibb: !p.iibb }))}>
            <span className="cb">{impuestos.iibb && <Ico.Check />}</span>
            <div className="body">
              <div className="name">IIBB 5</div>
              <div className="sub">iibb</div>
            </div>
            <span className="pct">5.00%</span>
          </div>
          <div className={`checkpill ${impuestos.iva ? "on" : ""}`} onClick={() => setImpuestos((p) => ({ ...p, iva: !p.iva }))}>
            <span className="cb">{impuestos.iva && <Ico.Check />}</span>
            <div className="body">
              <div className="name">IVA 21%</div>
              <div className="sub">iva_21</div>
            </div>
            <span className="pct">21.00%</span>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--hairline)" }}>
          <div style={{ fontSize: 12.5, color: "var(--muted)" }}>
            Total impuestos seleccionados: <strong style={{ color: "var(--ink)", fontFamily: "var(--font-mono)", fontWeight: 600 }}>{totalImpuestos.toFixed(2)}%</strong>
          </div>
          <button className="btn btn-primary">Guardar selección</button>
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Comisiones</h2>
            <div className="helptext">Esquemas reusables de comisiones (vendedor, financiera, etc.) que se cobran al cotizar este producto.</div>
          </div>
          <button className="btn"><Ico.External /> Administrar catálogo</button>
        </div>

        <div className="section-empty">
          <div className="ttl">Sin comisiones en el catálogo</div>
          <div className="sub">Antes de aplicar comisiones a este producto, creá al menos una en el catálogo del tenant.</div>
          <button className="btn btn-primary"><Ico.External /> Ir al catálogo</button>
        </div>
      </div>

      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Precios especiales por cliente</h2>
            <div className="helptext">Override del precio standard cuando el cliente X compra este producto. Cada precio especial usa su propio método de cálculo.</div>
          </div>
          <button className="btn btn-primary"><Ico.Plus /> Agregar</button>
        </div>

        <div className="section-empty">
          <div className="ttl">Sin precios especiales configurados</div>
          <div className="sub">Por default todos los clientes pagan el precio standard. Si querés cobrar distinto a algún cliente puntual, agregalo acá.</div>
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 4 }}>
        <button className="btn btn-primary" style={{ height: 38, padding: "0 16px" }}>
          <Ico.Save /> Guardar pricing
        </button>
      </div>
    </>
  );
}

Object.assign(window, {
  WIZ_STEPS, WizardTabs, WizardHeader,
  StepIdentidad, StepRutas, StepPasos, StepCargos, StepPricing,
  Tooltip,
});

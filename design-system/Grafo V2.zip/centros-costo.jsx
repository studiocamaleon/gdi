// Centros de costo — multi-tenant: Plantas / Areas / Centros

const PLANTAS = [{ code: "PLT-001", name: "Planta principal", state: "Activa" }];
const AREAS = [
  { plant: "Planta principal", code: "IMP", name: "Impresion", state: "Activa" },
  { plant: "Planta principal", code: "PRE", name: "Preprensa", state: "Activa" },
  { plant: "Planta principal", code: "TER", name: "Terminacion", state: "Activa" },
];
const CENTROS = [
  { centro: "Barniz UV tercerizado", plant: "Planta principal", area: "Terminacion", tipo: "Tercerizado", costeo: "Publicado", periodo: "2026-05", horas: null, tarifaPub: 22727, abs: null, tarifaTot: 22727, state: "Activo" },
  { centro: "CTP principal", plant: "Planta principal", area: "Preprensa", tipo: "Productivo", costeo: "Publicado", periodo: "2026-05", horas: null, tarifaPub: 6000, abs: null, tarifaTot: 6000, state: "Activo" },
  { centro: "Diseño grafico e Impresion Laser", plant: "Planta principal", area: "Impresion", tipo: "Productivo", costeo: "Publicado", periodo: "2026-05", horas: 115.6, tarifaPub: 22727, abs: null, tarifaTot: 22727, state: "Activo" },
];

function CentrosCosto() {
  const [tab, setTab] = React.useState("plantas");
  const [costoSheet, setCostoSheet] = React.useState(null);

  return (
    <>
      <div className="page-head">
        <div className="title-block">
          <h1>Centros de costo</h1>
          <div className="sub">Administra la estructura multi-tenant de plantas, áreas y centros de costo para el costeo operativo de la gráfica.</div>
        </div>
        <button className="btn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
          Refrescar
        </button>
      </div>

      <div className="cc-tabs">
        <button className={`cc-tab ${tab === "plantas" ? "active" : ""}`} onClick={() => setTab("plantas")}>Plantas</button>
        <button className={`cc-tab ${tab === "areas" ? "active" : ""}`} onClick={() => setTab("areas")}>Áreas</button>
        <button className={`cc-tab ${tab === "centros" ? "active" : ""}`} onClick={() => setTab("centros")}>Centros</button>
      </div>

      {tab === "plantas" && <PlantasTab />}
      {tab === "areas" && <AreasTab />}
      {tab === "centros" && <CentrosTab onConfigurarCosto={(c) => setCostoSheet(c)} />}

      {costoSheet && <ConfigurarCostoSheet centro={costoSheet} onClose={() => setCostoSheet(null)} />}
    </>
  );
}

function PlantasTab() {
  return (
    <>
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Plantas</h2>
            <div className="helptext">Una planta representa una sede o establecimiento productivo del tenant actual.</div>
          </div>
        </div>
        <div className="cc-form-grid cols-3">
          <div className="field"><label>Código</label><input type="text" defaultValue="PLT-001" /></div>
          <div className="field"><label>Nombre</label><input type="text" defaultValue="Planta principal" /></div>
          <div className="field"><label>Descripción</label><input type="text" placeholder="Observaciones" /></div>
        </div>
        <button className="btn btn-primary"><Ico.Plus />Nueva planta</button>
      </div>

      <div className="card">
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 200 }}>Código</th>
              <th>Nombre</th>
              <th style={{ width: 120 }}>Estado</th>
              <th className="right" style={{ width: 200 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {PLANTAS.map((p) => (
              <tr key={p.code}>
                <td><span className="code">{p.code}</span></td>
                <td className="name">{p.name}</td>
                <td><span className="tag ok"><span className="d" />{p.state}</span></td>
                <td className="right">
                  <span style={{ display: "inline-flex", gap: 6 }}>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}><Ico.Edit />Editar</button>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}>Inactivar</button>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function AreasTab() {
  return (
    <>
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Áreas</h2>
            <div className="helptext">Cada área ordena departamentos funcionales dentro de una planta.</div>
          </div>
        </div>
        <div className="cc-form-grid cols-4">
          <div className="field">
            <label>Planta</label>
            <div className="control select" style={{ height: 36 }}><span>Planta principal</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
          <div className="field"><label>Código</label><input type="text" placeholder="PRE" /></div>
          <div className="field"><label>Nombre</label><input type="text" placeholder="Preprensa" /></div>
          <div className="field"><label>Descripción</label><input type="text" placeholder="Observaciones" /></div>
        </div>
        <button className="btn btn-primary"><Ico.Plus />Nueva área</button>
      </div>

      <div className="card">
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 200 }}>Planta</th>
              <th style={{ width: 120 }}>Código</th>
              <th>Nombre</th>
              <th style={{ width: 120 }}>Estado</th>
              <th className="right" style={{ width: 200 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {AREAS.map((a) => (
              <tr key={a.code}>
                <td>{a.plant}</td>
                <td><span className="code">{a.code}</span></td>
                <td className="name">{a.name}</td>
                <td><span className="tag ok"><span className="d" />{a.state}</span></td>
                <td className="right">
                  <span style={{ display: "inline-flex", gap: 6 }}>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}><Ico.Edit />Editar</button>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}>Inactivar</button>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function CentrosTab({ onConfigurarCosto }) {
  const fmt = (n) => n == null ? "—" : n.toLocaleString("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).replace("ARS", "$");
  return (
    <>
      <div className="wiz-section">
        <div className="wiz-section-head">
          <div className="body">
            <h2>Centros de costo</h2>
            <div className="helptext">Define el punto real de imputación con clasificación gráfica, responsables y reglas operativas del centro.</div>
          </div>
        </div>
        <div className="cc-form-grid cols-cc">
          <div className="field"><label>Planta</label><div className="control select" style={{ height: 36 }}><span>Planta principal</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Área</label><div className="control select" style={{ height: 36 }}><span>Impresion</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Código</label><input type="text" placeholder="IMP-002" /></div>
          <div className="field"><label>Nombre</label><input type="text" placeholder="CTP principal" /></div>
          <div className="field"><label>Tipo</label><div className="control select" style={{ height: 36 }}><span>Productivo</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Categoría gráfica</label><div className="control select" style={{ height: 36 }}><span>Preprensa</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Imputación</label><div className="control select" style={{ height: 36 }}><span>Directa</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Unidad base futura</label><div className="control select" style={{ height: 36 }}><span>Ninguna</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field"><label>Responsable</label><div className="control select" style={{ height: 36 }}><span style={{ color: "var(--muted)" }}>Sin responsable</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div></div>
          <div className="field" style={{ gridColumn: "span 3" }}><label>Descripción</label><input type="text" placeholder="Comentarios operativos" /></div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 14px", background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)", marginBottom: 14 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 500, fontSize: 13 }}>Activo</div>
            <div style={{ fontSize: 11.5, color: "var(--muted)" }}>Determina si se puede seguir imputando</div>
          </div>
          <span className="switch-lg on" />
        </div>

        <button className="btn btn-primary"><Ico.Plus />Nuevo centro</button>
      </div>

      <div className="card">
        <table className="tbl">
          <thead>
            <tr>
              <th>Centro</th>
              <th>Área</th>
              <th>Tipo</th>
              <th>Estado costeo</th>
              <th>Período</th>
              <th className="right">Horas productivas</th>
              <th className="right">Tarifa publicada</th>
              <th className="right">Absorbido</th>
              <th className="right">Tarifa total</th>
              <th>Estado</th>
              <th className="right" style={{ width: 280 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {CENTROS.map((c) => (
              <tr key={c.centro}>
                <td>
                  <div className="name">{c.centro}</div>
                  <div className="desc" style={{ fontFamily: "var(--font-mono)", fontSize: 11 }}>{c.plant} / {c.area}</div>
                </td>
                <td>{c.area}</td>
                <td><span className="tag" style={{ background: c.tipo === "Tercerizado" ? "var(--signal-bg)" : "var(--surface-2)", color: c.tipo === "Tercerizado" ? "var(--signal)" : "var(--ink-2)", borderColor: c.tipo === "Tercerizado" ? "#f4d3c0" : "var(--border)" }}>{c.tipo}</span></td>
                <td><span className="tag ok"><span className="d" />{c.costeo}</span></td>
                <td style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{c.periodo}</td>
                <td className="right" style={{ fontVariantNumeric: "tabular-nums" }}>{c.horas != null ? c.horas.toLocaleString("es-AR") : "—"}</td>
                <td className="right" style={{ fontVariantNumeric: "tabular-nums" }}>{fmt(c.tarifaPub)}</td>
                <td className="right" style={{ color: "var(--muted)" }}>—</td>
                <td className="right" style={{ fontVariantNumeric: "tabular-nums", fontWeight: 500 }}>{fmt(c.tarifaTot)}</td>
                <td><span className="tag ok"><span className="d" />{c.state}</span></td>
                <td className="right">
                  <span style={{ display: "inline-flex", gap: 6 }}>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }} onClick={() => onConfigurarCosto?.(c.centro)}><Ico.Sliders />Configurar costo</button>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}><Ico.Edit />Editar</button>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }}>Inactivar</button>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="kpi-row">
        <div className="kpi-card">
          <div className="lbl"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6v6H9z"/></svg>Plantas</div>
          <div className="val">1</div>
        </div>
        <div className="kpi-card">
          <div className="lbl"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 5-5"/></svg>Áreas</div>
          <div className="val">3</div>
        </div>
        <div className="kpi-card">
          <div className="lbl"><Ico.Coin />Centros activos</div>
          <div className="val">3</div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { CentrosCosto });

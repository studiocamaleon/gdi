// Dark sidebar — Grafoprint
// Mirrors the original IA: Panel general / Comercial / Registros / Costos (expanded) / Produccion / Inventario
// Plan card at bottom, refined (no rainbow gradient).

const NAV = [
  { key: "panel", label: "Panel general", icon: "Grid" },
  {
    key: "comercial",
    label: "Comercial",
    icon: "Briefcase",
    children: [
      { key: "crear-cotizacion", label: "Crear cotización" },
    ],
  },
  {
    key: "registros",
    label: "Registros",
    icon: "Users",
    children: [
      { key: "clientes", label: "Clientes" },
      { key: "proveedores", label: "Proveedores" },
      { key: "empleados", label: "Empleados" },
    ],
  },
  {
    key: "costos",
    label: "Costos",
    icon: "Coin",
    children: [
      { key: "centros", label: "Centros de costo" },
      { key: "maquinaria", label: "Maquinaria" },
      { key: "rutas", label: "Rutas de producción" },
      { key: "catalogo", label: "Catálogo de productos" },
      { key: "cargos", label: "Cargos directos" },
      { key: "impuestos", label: "Impuestos" },
      { key: "comisiones", label: "Comisiones" },
    ],
  },
  {
    key: "produccion",
    label: "Producción",
    icon: "Factory",
    children: [
      { key: "estaciones", label: "Estaciones" },
    ],
  },
  {
    key: "inventario",
    label: "Inventario",
    icon: "Cube",
    children: [
      { key: "materiales", label: "Materiales" },
      { key: "movimientos", label: "Movimientos" },
    ],
  },
];

function Sidebar({ logoVariant, activeKey, onNavigate }) {
  const [expanded, setExpanded] = React.useState(() => new Set(["costos"]));

  const isActive = (childKey) => activeKey === childKey;
  const isParentOfActive = (item) => item.children?.some(c => c.key === activeKey);

  const toggle = (key) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  return (
    <aside className="side">
      <Brand variant={logoVariant} />

      <div className="side-search" onClick={() => {}}>
        <Ico.Search />
        <span>Buscar…</span>
        <span className="kbd">⌘K</span>
      </div>

      <nav className="side-nav">
        {NAV.map(item => {
          const IconCmp = Ico[item.icon];
          const hasChildren = !!item.children?.length;
          const open = expanded.has(item.key);
          const parentActive = isParentOfActive(item);
          return (
            <React.Fragment key={item.key}>
              <div
                className={`nav-item ${open ? "expanded" : ""} ${(!hasChildren && activeKey === item.key) || parentActive ? "" : ""}`}
                onClick={() => {
                  if (hasChildren) toggle(item.key);
                  else onNavigate(item.key);
                }}
              >
                <span className="ico"><IconCmp /></span>
                <span className="label">{item.label}</span>
                {hasChildren && <Ico.Chev className="chev" />}
              </div>

              {hasChildren && open && (
                <div className="nav-children">
                  {item.children.map(child => (
                    <div
                      key={child.key}
                      className={`nav-child ${isActive(child.key) ? "active" : ""}`}
                      onClick={() => onNavigate(child.key)}
                    >
                      <span>{child.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </React.Fragment>
          );
        })}
      </nav>

      <div className="plan-card">
        <div className="plan-row">
          <div className="plan-title">
            <span className="dot" />
            <div>
              <div className="name">Plan diamante</div>
              <div className="tier">14 / 30 dias restantes</div>
            </div>
          </div>
        </div>
        <div className="plan-meter"><span style={{ width: "46%" }} /></div>
        <div className="plan-admin" onClick={() => onNavigate("administrar")}>Administrar suscripción</div>
      </div>
    </aside>
  );
}

Object.assign(window, { Sidebar });

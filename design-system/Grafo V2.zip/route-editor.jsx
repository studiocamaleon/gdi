// Route editor — edit a single route's identity + ordered steps
// Family picker is a rich custom select (grouped families, with code + description)

const FAMILIES = [
  {
    group: "Producción",
    items: [
      { key: "diseno_grafico", name: "Diseño gráfico", code: "diseno_grafico", desc: "Diseño y armado del archivo gráfico antes de pre-prensa." },
      { key: "pre_prensa", name: "Pre-prensa / armado de imposición", code: "pre_prensa", desc: "Armado de chapas, plantillas y imposición sobre la hoja." },
      { key: "impresion_hoja", name: "Impresión por hoja", code: "impresion_hoja", desc: "Tiempo y costo en base a productividad por hoja." },
      { key: "impresion_area", name: "Impresión por área", code: "impresion_area", desc: "Tiempo y costo en base a m² impresos." },
      { key: "laminado", name: "Laminado", code: "laminado", desc: "Aplicación de film protector. Productividad de la máquina." },
    ],
  },
  {
    group: "Modificaciones",
    items: [
      { key: "modificacion_pre", name: "Modificación pre-producción", code: "modificacion_pre", desc: "Modificación física que MUTA el JobContext (medidas, etc.) antes de los pasos de producción. Ej: bolsillos en lona, refuerzos en bordes, dobladillo." },
      { key: "modificacion_post", name: "Modificación post-producción", code: "modificacion_post", desc: "Modificación física que se ejecuta DESPUÉS de los pasos de producción (sin alterar valores previos). Ej: perforaciones, redondeo de puntas, numeración." },
    ],
  },
  {
    group: "Corte y terminación",
    items: [
      { key: "cnc", name: "CNC", code: "cnc", desc: "Corte CNC en MDF, PVC u otros rígidos." },
      { key: "plotter_corte", name: "Plotter de corte", code: "plotter_corte", desc: "Corte vectorial sobre vinilo u otros flexibles." },
      { key: "corte_guillotina", name: "Corte con guillotina", code: "corte_guillotina", desc: "Refilado / corte a medida en guillotina." },
      { key: "lijado", name: "Lijado / canteado de bordes", code: "lijado", desc: "Tratamiento de bordes para rígidos cortados." },
      { key: "pintura", name: "Pintura superficial", code: "pintura_superficial", desc: "Pintura o teñido superficial de la pieza." },
    ],
  },
  {
    group: "Encuadernación",
    items: [
      { key: "engrapado", name: "Engrapado (caballete / lateral)", code: "engrapado", desc: "Encuadernación por engrapado central o lateral." },
      { key: "engomado", name: "Engomado / emblocado", code: "engomado", desc: "Encuadernación por engomado para talonarios." },
      { key: "conteo_manual", name: "Conteo manual", code: "conteo_manual", desc: "Conteo manual de hojas/piezas durante el armado." },
    ],
  },
  {
    group: "Logística / instalación in situ",
    items: [
      { key: "envio", name: "Envío / despacho", code: "envio", desc: "Envío del producto al cliente. Cargos directos asociados (combustible, flete)." },
      { key: "instalacion_in_situ", name: "Instalación en sitio", code: "instalacion_in_situ", desc: "Instalación física del producto en domicilio del cliente." },
      { key: "embalaje", name: "Embalaje", code: "embalaje", desc: "Empaque final antes del despacho." },
    ],
  },
];

const FAMILY_BY_NAME = {};
FAMILIES.forEach((g) => g.items.forEach((f) => { FAMILY_BY_NAME[f.name] = f; }));

function FamilyPicker({ value, onChange }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  return (
    <div className={`family-picker ${open ? "open" : ""}`} ref={ref}>
      <button className="control" type="button" onClick={() => setOpen((o) => !o)}>
        <span className={`val ${value ? "" : "empty"}`}>{value || "Elegí familia…"}</span>
        <span className="chev">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </span>
      </button>
      {open && (
        <div className="family-menu">
          {FAMILIES.map((g) => (
            <div key={g.group}>
              <div className="family-group">{g.group}</div>
              {g.items.map((f) => (
                <div
                  key={f.key}
                  className={`family-option ${value === f.name ? "selected" : ""}`}
                  onClick={() => { onChange(f.name); setOpen(false); }}
                >
                  <div className="name">{f.name}</div>
                  <div className="code">{f.code}</div>
                  <div className="desc">{f.desc}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const RUTAS_DETAIL = {
  "RUTA-RIGIDO-CUSTOM": {
    code: "RUTA-RIGIDO-CUSTOM",
    name: "Rígido impreso custom",
    desc: "Rutas para rígidos impresos en MDF/PVC con corte CNC/manual/láser",
    steps: [
      "Diseño gráfico",
      "Pre-prensa / armado de imposición",
      "Impresión por área",
      "CNC",
      "Lijado / canteado de bordes",
      "Pintura superficial",
      "Embalaje",
      "Instalación en sitio",
    ],
    active: true,
    usage: 1,
    history: [{ version: "v1", label: "Versión inicial", date: "29/4/2026" }],
  },
};

function RouteEditor({ code, onBack }) {
  const initial = RUTAS_DETAIL[code] || RUTAS_DETAIL["RUTA-RIGIDO-CUSTOM"];
  const [name, setName] = React.useState(initial.name);
  const [desc, setDesc] = React.useState(initial.desc);
  const [active, setActive] = React.useState(initial.active);
  const [steps, setSteps] = React.useState(initial.steps);

  const updateStep = (i, val) => setSteps((prev) => prev.map((s, j) => j === i ? val : s));
  const removeStep = (i) => setSteps((prev) => prev.filter((_, j) => j !== i));
  const moveStep = (i, dir) => {
    setSteps((prev) => {
      const next = [...prev];
      const j = i + dir;
      if (j < 0 || j >= next.length) return prev;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  };
  const addStep = () => setSteps((prev) => [...prev, ""]);

  return (
    <div className="route-editor">
      <a className="back-link" onClick={onBack}><Ico.Back /> Volver a Rutas</a>

      <div className="route-head">
        <div className="title-block">
          <h1><span className="ed">Editar ruta:</span> {initial.name}</h1>
          <div className="meta">
            <span className="tag version">v1</span>
            <span className="code">{initial.code}</span>
            <span>·</span>
            <span>usado por <strong style={{ color: "var(--ink)", fontWeight: 500 }}>{initial.usage}</strong> producto(s)</span>
          </div>
        </div>
        <div className="actions">
          <div className="active-toggle">
            <span>{active ? "Activa" : "Inactiva"}</span>
            <span className={`switch-lg ${active ? "on" : ""}`} onClick={() => setActive(!active)} />
          </div>
        </div>
      </div>

      <div className="route-cols">
        <div className="wiz-section" style={{ marginBottom: 0 }}>
          <div className="wiz-section-head">
            <div className="body">
              <h2>Identidad</h2>
              <div className="helptext">Código y nombre de la ruta reusable.</div>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div className="field">
              <label>Código <span className="req">*</span></label>
              <input type="text" className="locked" value={initial.code} readOnly />
            </div>
            <div className="field">
              <label>Nombre <span className="req">*</span></label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="field">
              <label>Descripción</label>
              <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={4} />
            </div>
          </div>
        </div>

        <div className="wiz-section" style={{ marginBottom: 0 }}>
          <div className="wiz-section-head">
            <div className="body">
              <h2>Pasos en orden</h2>
              <div className="helptext">Cada paso es una familia del catálogo. El producto configura máquinas y materiales después.</div>
            </div>
            <button className="btn" onClick={addStep}><Ico.Plus /> Agregar paso</button>
          </div>

          <div className="step-list">
            {steps.map((s, i) => (
              <div className="step-row" key={i}>
                <span className="ix">{i + 1}</span>
                <FamilyPicker value={s} onChange={(v) => updateStep(i, v)} />
                <button className="iconbtn" onClick={() => moveStep(i, -1)} disabled={i === 0} title="Subir">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 15-6-6-6 6"/></svg>
                </button>
                <button className="iconbtn" onClick={() => moveStep(i, 1)} disabled={i === steps.length - 1} title="Bajar">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                </button>
                <button className="iconbtn danger" onClick={() => removeStep(i)} title="Quitar paso">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 6 12 12M18 6 6 18"/></svg>
                </button>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 14, padding: 12, background: "var(--surface-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)", fontSize: 11.5, color: "var(--muted)", lineHeight: 1.5 }}>
            <strong style={{ color: "var(--ink)", fontWeight: 500 }}>Tip:</strong> el orden de los pasos determina el flujo de producción. Las modificaciones <span style={{ fontFamily: "var(--font-mono)" }}>pre</span> mutan el JobContext (medidas etc) antes de la producción; las <span style={{ fontFamily: "var(--font-mono)" }}>post</span> se ejecutan después sin alterar valores previos.
          </div>
        </div>
      </div>

      <div className="card versions-block">
        <div className="card-head">
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 3"/></svg>
            <span className="title">Historial de versiones</span>
          </span>
        </div>
        {initial.history.map((v) => (
          <div className="versions-row" key={v.version}>
            <span className="vtag">{v.version}</span>
            <span className="vname">{v.label}</span>
            <span className="vdate">{v.date}</span>
          </div>
        ))}
      </div>

      <div className="route-actions-bar">
        <button className="btn btn-danger"><Ico.Trash /> Eliminar ruta</button>
        <span style={{ flex: 1, fontSize: 11.5, color: "var(--muted)", marginLeft: 12 }}>
          Los cambios se aplican al guardar. Si querés versionar, se creará v2 automáticamente.
        </span>
        <button className="btn">Cancelar</button>
        <button className="btn btn-primary"><Ico.Save /> Guardar cambios</button>
      </div>
    </div>
  );
}

Object.assign(window, { RouteEditor, FamilyPicker, FAMILIES });

// Maquinaria — listado de máquinas
const MAQUINAS = [
  { code: "FELDER-F500", name: "Felder F500 CNC", template: "Router CNC", state: "Activa", perfiles: 1 },
  { code: "LAM-BOPP-001", name: "Laminadora BOPP rollo", template: "Laminadora BOPP rollo", state: "Activa", perfiles: 1 },
  { code: "MIMAKI-UJF-7151", name: "Mimaki UJF-7151plus", template: "Impresora gran formato por área", state: "Activa", perfiles: 2 },
  { code: "POLAR-92", name: "Polar 92 ED", template: "Guillotina", state: "Activa", perfiles: 3 },
  { code: "RICOH-PRO-C5100", name: "Ricoh PRO C5100", template: "Impresora láser", state: "Activa", perfiles: 2, primary: true },
  { code: "ROLAND-VG3-540", name: "Roland TrueVIS VG3-540", template: "Impresora gran formato por área", state: "Activa", perfiles: 1 },
  { code: "SKYCUT-C24", name: "Skycut C24", template: "Plotter de corte", state: "Activa", perfiles: 2 },
];

function MaquinariaList({ onOpenMaquina }) {
  const [query, setQuery] = React.useState("");
  const [tpl, setTpl] = React.useState("Todas");

  const templates = ["Todas", ...Array.from(new Set(MAQUINAS.map(m => m.template)))];
  const matches = MAQUINAS.filter(m =>
    (!query || m.code.toLowerCase().includes(query.toLowerCase()) || m.name.toLowerCase().includes(query.toLowerCase())) &&
    (tpl === "Todas" || m.template === tpl)
  );

  return (
    <>
      <div className="page-head">
        <div className="title-block">
          <h1>Maquinaria</h1>
          <div className="sub">Catálogo de máquinas + perfiles operativos. Modelo v3.0 alineado a doc §5–§13.</div>
        </div>
        <button className="btn btn-primary"><Ico.Plus />Nueva máquina</button>
      </div>

      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ padding: 16, display: "grid", gridTemplateColumns: "1fr 220px", gap: 12 }}>
          <div className="field" style={{ margin: 0 }}>
            <label>Buscar</label>
            <input type="text" placeholder="Nombre o código…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="field" style={{ margin: 0 }}>
            <label>Plantilla</label>
            <select value={tpl} onChange={(e) => setTpl(e.target.value)} style={{ width: "100%", padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "var(--r-2)", background: "var(--surface)", font: "inherit", fontSize: 13 }}>
              {templates.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head"><span className="title">Máquinas</span><span className="count">{matches.length}</span></div>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 36 }}></th>
              <th style={{ width: 200 }}>Código</th>
              <th>Nombre</th>
              <th style={{ width: 260 }}>Plantilla</th>
              <th style={{ width: 110 }}>Estado</th>
              <th className="right" style={{ width: 90 }}>Perfiles</th>
              <th className="right" style={{ width: 130 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {matches.map(m => (
              <tr key={m.code} onClick={() => onOpenMaquina(m.code)}>
                <td><span className="ok-pill"><Ico.Check /></span></td>
                <td><span className="code">{m.code}</span></td>
                <td className="name">{m.name}</td>
                <td><span className="tag" style={{ background: "var(--surface-2)" }}>{m.template}</span></td>
                <td><span className="tag ok"><span className="d" />{m.state}</span></td>
                <td className="right" style={{ fontVariantNumeric: "tabular-nums" }}>{m.perfiles}</td>
                <td className="right">
                  <span style={{ display: "inline-flex", gap: 6 }}>
                    <button className="btn" style={{ height: 28, padding: "0 10px", fontSize: 12 }} onClick={(e) => { e.stopPropagation(); onOpenMaquina(m.code); }}>Editar</button>
                    <button className="icon-btn" onClick={(e) => e.stopPropagation()} title="Eliminar"><Ico.Trash /></button>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ─────────────────────────────── Detail page
function Accordion({ icon, title, sub, summary, defaultOpen = false, children }) {
  const [open, setOpen] = React.useState(defaultOpen);
  const IconCmp = icon ? Ico[icon] : null;
  return (
    <div className={`acc ${open ? "open" : "closed"}`}>
      <div className="acc-head" onClick={() => setOpen(!open)}>
        {IconCmp && <span className="ico"><IconCmp /></span>}
        <div className="body">
          <div className="ttl">{title}</div>
          {sub && <div className="sub">{sub}</div>}
        </div>
        {summary && <div className="summary"><span className="dot" />{summary}</div>}
        <span className="chev"><Ico.Chev /></span>
      </div>
      <div className="acc-body">{children}</div>
    </div>
  );
}

const CMYK = [
  { key: "cian", name: "Cian", color: "#00aeef" },
  { key: "magenta", name: "Magenta", color: "#ec008c" },
  { key: "amarillo", name: "Amarillo", color: "#fff200" },
  { key: "negro", name: "Negro", color: "#000000" },
];

function ConsumibleSet({ name, sub, channels = CMYK }) {
  return (
    <div className="canal-set">
      <div className="csh">
        <div>
          <div className="nm">{name}</div>
          <div className="sub">{sub}</div>
        </div>
        <span style={{ flex: 1 }} />
        <span className="count">{channels.length} canales</span>
      </div>
      {channels.map((c, i) => (
        <div className="canal-row" key={c.key}>
          <div className="canal-name">
            <span className="swatch" style={{ background: c.color, border: c.color === "#000000" ? "1px solid var(--border)" : "none" }} />
            <div>
              <span className="lbl-small">Canal</span>
              <div>{c.name}</div>
            </div>
          </div>
          <div>
            <span className="stack-lbl">Variante vinculada</span>
            <div className="control select" style={{ height: 32, fontSize: 12.5 }}>
              <span>Tóner CMYK Ricoh PRO C5100 · {c.name}</span>
              <Ico.Chev style={{ transform: "rotate(90deg)" }} />
            </div>
          </div>
          <div>
            <span className="stack-lbl">Consumo (g/m²)</span>
            <input type="number" defaultValue="1.73" step="0.01" />
          </div>
          <div>
            <span className="stack-lbl">Contenido</span>
            <input type="number" defaultValue="500" />
          </div>
          <div>
            <span className="stack-lbl">&nbsp;</span>
            <div className="activo-toggle">
              <span className="check on"><Ico.Check /></span>
              Activo
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function PerfilOperativo({ num, name, defaults }) {
  return (
    <div className="perfil-card">
      <div className="ph">
        <span className="num">{num}</span>
        <span className="nm">{name}</span>
        <div className="actions">
          <button className="icon-btn" title="Duplicar"><Ico.Edit /></button>
          <button className="icon-btn" title="Quitar"><Ico.Trash /></button>
        </div>
      </div>
      <div className="pb">
        <div className="field">
          <label>Tipo de perfil <Tooltip /></label>
          <div className="control select" style={{ height: 36 }}><span>{defaults.tipo || "Impresion"}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
        </div>
        <div className="field">
          <label>Nombre del perfil <span className="req">*</span></label>
          <input type="text" defaultValue={name} />
          <span className="help">Ej: Papel grueso doble faz.</span>
        </div>
        <div className="field">
          <label>Productividad <span className="req">*</span></label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" defaultValue={defaults.productividad} style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>ppm</span>
          </div>
          <span className="help">Pliegos por minuto.</span>
        </div>
        <div className="field">
          <label>Setup</label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" defaultValue={defaults.setup || 5} style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>min</span>
          </div>
          <span className="help">Tiempo de preparación inicial.</span>
        </div>
        <div className="field">
          <label>Cleanup</label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" defaultValue={defaults.cleanup || 2} style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>min</span>
          </div>
          <span className="help">Tiempo de limpieza al terminar.</span>
        </div>
        <div className="field">
          <label>Recarga papel</label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" placeholder="—" style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>min</span>
          </div>
          <span className="help">Tiempo de recarga entre tandas.</span>
        </div>
        <div className="field">
          <label>Caras <span className="req">*</span></label>
          <div className="control select" style={{ height: 36 }}><span>{defaults.caras || "Simple faz"}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          <span className="help">Discriminante: simple o doble faz.</span>
        </div>
        <div className="field">
          <label>Colores</label>
          <div className="control select" style={{ height: 36 }}><span>{defaults.colores || "CMYK"}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          <span className="help">Modo de color del perfil.</span>
        </div>
        <div className="field">
          <label>Formato</label>
          <div className="control select" style={{ height: 36 }}><span>{defaults.formato || "SRA3"}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          <span className="help">Formato máximo del perfil.</span>
        </div>
        <div className="field">
          <label>Gramaje mínimo</label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" defaultValue={defaults.gMin || 200} style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>g/m²</span>
          </div>
          <span className="help">Gramaje mínimo del rango.</span>
        </div>
        <div className="field">
          <label>Gramaje máximo</label>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="number" defaultValue={defaults.gMax || 350} style={{ flex: 1 }} />
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5, color: "var(--muted)" }}>g/m²</span>
          </div>
          <span className="help">Gramaje máximo del rango.</span>
        </div>
      </div>
    </div>
  );
}

function MaquinaDetail({ code, onBack }) {
  const m = MAQUINAS.find(x => x.code === code) || MAQUINAS.find(x => x.code === "RICOH-PRO-C5100");
  const [active, setActive] = React.useState(true);

  return (
    <div className="maq-detail">
      <a className="back-link" onClick={onBack}><Ico.Back /> Volver a Maquinaria</a>

      <div className="maq-head">
        <div className="title-block">
          <h1>
            {m.name}
            <span className="tag ok"><span className="d" />Activa</span>
          </h1>
          <div className="meta">
            <span className="code">{m.code}</span>
            <span>·</span>
            <span>Plantilla <strong style={{ color: "var(--ink)", fontWeight: 500 }}>{m.template}</strong></span>
            <span>·</span>
            <span>Planta principal · Centro Diseño gráfico e Impresión Láser</span>
          </div>
        </div>
        <div className="actions">
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "var(--muted)" }}>
            <span>{active ? "Activa" : "Inactiva"}</span>
            <span className={`switch-lg ${active ? "on" : ""}`} onClick={() => setActive(!active)} />
          </div>
          <button className="btn">Duplicar</button>
          <button className="btn btn-primary"><Ico.Save /> Guardar cambios</button>
        </div>
      </div>

      <div className="acc-info">
        Completá los campos según la plantilla elegida. Los discriminantes específicos se editan en cada perfil operativo.
      </div>

      {/* Identidad — always open */}
      <Accordion icon="Tag" title="Identidad" sub="Código, nombre, plantilla y centro de costo" defaultOpen={true} summary="Completo">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <div className="field">
            <label>Código</label>
            <input type="text" className="locked" value={m.code} readOnly />
          </div>
          <div className="field">
            <label>Nombre <span className="req">*</span></label>
            <input type="text" defaultValue={m.name} />
          </div>
          <div className="field">
            <label>Plantilla <Tooltip /></label>
            <div className="control select" style={{ height: 36 }}><span>{m.template}</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
          <div className="field">
            <label>Estado</label>
            <div className="control select" style={{ height: 36 }}><span>Activa</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
          <div className="field">
            <label>Planta</label>
            <div className="control select" style={{ height: 36 }}><span>Planta principal</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
          <div className="field">
            <label>Centro de costo</label>
            <div className="control select" style={{ height: 36 }}><span>Diseño gráfico e Impresión Láser</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
          </div>
          <div className="field" style={{ gridColumn: "1 / -1" }}>
            <label>Geometría de trabajo <Tooltip /></label>
            <div className="control select" style={{ height: 36 }}><span>Pliego</span><Ico.Chev style={{ transform: "rotate(90deg)" }} /></div>
            <span className="help">Define cómo se calcula la cantidad de imposiciones en función del archivo del cliente.</span>
          </div>
        </div>
      </Accordion>

      <Accordion icon="Cube" title="Capacidades físicas" sub="Medidas máximas de pliego soportadas por la máquina" summary="Completo">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
          <div className="field">
            <label>Pliego máximo · ancho <span className="hint">mm</span></label>
            <input type="number" defaultValue="330" />
          </div>
          <div className="field">
            <label>Pliego máximo · alto <span className="hint">mm</span></label>
            <input type="number" defaultValue="487" />
          </div>
          <div className="field">
            <label>Área útil máxima <span className="hint">mm²</span></label>
            <input type="text" className="locked" value="160 710" readOnly />
          </div>
        </div>
      </Accordion>

      <Accordion icon="Sliders" title="Parámetros técnicos" sub="Configuración específica de la impresora láser" summary="Completo">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <div className="field">
            <label>Resolución nativa <span className="hint">dpi</span></label>
            <input type="number" defaultValue="1200" />
          </div>
          <div className="field">
            <label>Velocidad nominal <span className="hint">ppm</span></label>
            <input type="number" defaultValue="80" />
          </div>
          <div className="field">
            <label>Caja entrada · capacidad <span className="hint">hojas</span></label>
            <input type="number" defaultValue="4400" />
          </div>
          <div className="field">
            <label>Caja salida · capacidad <span className="hint">hojas</span></label>
            <input type="number" defaultValue="3000" />
          </div>
        </div>
      </Accordion>

      <Accordion icon="Route" title="Perfiles operativos" sub="Cada perfil describe una combinación cara/color/formato/gramaje con su productividad" defaultOpen={true} summary="2 perfiles">
        <PerfilOperativo num={1} name="Papel grueso simple faz" defaults={{ tipo: "Impresion", productividad: 40, setup: 5, cleanup: 2, caras: "Simple faz", colores: "CMYK", formato: "SRA3", gMin: 200, gMax: 350 }} />
        <PerfilOperativo num={2} name="Papel grueso doble faz" defaults={{ tipo: "Impresion", productividad: 28, setup: 5, cleanup: 2, caras: "Doble faz", colores: "CMYK", formato: "SRA3", gMin: 200, gMax: 350 }} />
        <button className="btn" style={{ marginTop: 4 }}><Ico.Plus /> Agregar perfil operativo</button>
      </Accordion>

      <Accordion icon="Cube" title="Consumibles" sub="Tóner declarado por máquina" summary="2 sets · 8 canales">
        <div className="acc-info" style={{ marginBottom: 14 }}>
          Los consumibles de impresión se toman automáticamente en el motor desde la máquina y el perfil. En Productos ya no hace falta elegir un tóner o tinta por paso.
        </div>
        <ConsumibleSet
          name="Papel grueso simple faz"
          sub="Cian · Magenta · Amarillo · Negro"
        />
        <ConsumibleSet
          name="Papel grueso doble faz"
          sub="Cian · Magenta · Amarillo · Negro"
        />
        <button className="btn"><Ico.Plus /> Agregar set de consumibles</button>
      </Accordion>

      <Accordion icon="Trash" title="Desgaste y repuestos" sub="Fusor, drum, transferencia, etc." summary="3 ítems">
        <div className="step-list">
          {[
            { name: "Fusor", duracion: "300.000 impresiones", costo: 850 },
            { name: "Drum", duracion: "200.000 impresiones", costo: 1200 },
            { name: "Cinturón de transferencia", duracion: "500.000 impresiones", costo: 450 },
          ].map((r) => (
            <div className="step-row" style={{ gridTemplateColumns: "32px 1fr 1fr 1fr 32px 32px" }} key={r.name}>
              <span className="ix" style={{ borderRadius: "50%" }}></span>
              <input type="text" defaultValue={r.name} style={{ padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "var(--r-2)", font: "inherit", fontSize: 13 }} />
              <input type="text" defaultValue={r.duracion} style={{ padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "var(--r-2)", font: "inherit", fontSize: 13 }} />
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <span style={{ color: "var(--muted)", fontSize: 12 }}>USD</span>
                <input type="number" defaultValue={r.costo} style={{ flex: 1, padding: "8px 10px", border: "1px solid var(--border)", borderRadius: "var(--r-2)", font: "inherit", fontSize: 13, fontVariantNumeric: "tabular-nums", textAlign: "right" }} />
              </div>
              <button className="icon-btn" title="Editar"><Ico.Edit /></button>
              <button className="icon-btn" title="Quitar"><Ico.Trash /></button>
            </div>
          ))}
        </div>
        <button className="btn" style={{ marginTop: 12 }}><Ico.Plus /> Agregar repuesto</button>
      </Accordion>

      <div className="route-actions-bar">
        <button className="btn btn-danger"><Ico.Trash /> Eliminar máquina</button>
        <span style={{ flex: 1, fontSize: 11.5, color: "var(--muted)", marginLeft: 12 }}>
          Esta máquina es referenciada por <strong style={{ color: "var(--ink)" }}>2 perfiles operativos</strong> y <strong style={{ color: "var(--ink)" }}>3 rutas</strong>.
        </span>
        <button className="btn">Cancelar</button>
        <button className="btn btn-primary"><Ico.Save /> Guardar cambios</button>
      </div>
    </div>
  );
}

Object.assign(window, { MaquinariaList, MaquinaDetail, MAQUINAS });

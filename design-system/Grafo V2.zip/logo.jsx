// Three logo concepts for Grafoprint
// Each uses currentColor so it can be drawn on dark sidebar or light surfaces.

const LogoNodes = ({ size = 22 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden="true">
    {/* edges */}
    <path d="M5.5 6.5 L18 6.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    <path d="M5.5 6.5 L12 17.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    <path d="M18 6.5 L12 17.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    <path d="M18 6.5 L18 14.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" opacity="0.55" />
    {/* nodes */}
    <circle cx="5.5" cy="6.5" r="2.2" fill="currentColor" />
    <circle cx="18" cy="6.5" r="2.2" fill="currentColor" />
    <circle cx="12" cy="17.5" r="2.2" fill="currentColor" />
    <circle cx="18" cy="14.5" r="1.4" fill="currentColor" opacity="0.55" />
  </svg>
);

// Variant B — a small geometric monogram, "G" composed as a vertex set
const LogoMonogram = ({ size = 22 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden="true">
    <rect x="2" y="2" width="20" height="20" rx="6" fill="currentColor" />
    {/* internal mark — a node + arc, like a graph fragment */}
    <path
      d="M8 14.5 a4.5 4.5 0 1 1 7 0"
      stroke="white"
      strokeOpacity="0.95"
      strokeWidth="1.6"
      strokeLinecap="round"
      fill="none"
    />
    <circle cx="15" cy="14.6" r="1.7" fill="white" />
    <circle cx="8" cy="14.6" r="1.7" fill="white" />
  </svg>
);

// Variant C — minimalist directed edge: two vertices + connector
const LogoVertex = ({ size = 22 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden="true">
    <circle cx="5.5" cy="12" r="3" stroke="currentColor" strokeWidth="1.6" fill="none" />
    <circle cx="18.5" cy="12" r="3" fill="currentColor" />
    <path
      d="M8.8 12 L15.2 12"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
  </svg>
);

const LOGO_VARIANTS = {
  nodes: LogoNodes,
  monogram: LogoMonogram,
  vertex: LogoVertex,
};

// Brand block used in the sidebar
function Brand({ variant = "nodes" }) {
  const Mark = LOGO_VARIANTS[variant] || LogoNodes;
  return (
    <div className="side-brand">
      <div className="mark">
        <Mark size={28} />
      </div>
      <div>
        <div className="wordmark">grafoprint</div>
        <div className="org">motor de cotización</div>
      </div>
    </div>
  );
}

Object.assign(window, { LogoNodes, LogoMonogram, LogoVertex, LOGO_VARIANTS, Brand });

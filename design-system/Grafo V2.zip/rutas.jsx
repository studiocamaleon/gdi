// Rutas de producción — listado.
// Cada ruta es un esqueleto de pasos reusable que los productos pueden referenciar.

const RUTAS = [
  {
    code: "RUTA-RIGIDO-CUSTOM",
    name: "Rígido impreso custom",
    desc: "Rutas para rígidos impresos en MDF/PVC con corte CNC/manual/láser",
    steps: [
      "Diseño gráfico",
      "Pre-prensa / armado de imposición",
      "Impresión por área",
      "CNC",
      "Lijado / canteado de bordes",
      "Pintura superficial",
      "Embalaje",
      "Instalación en sitio",
    ],
    version: "v1",
    usage: 1,
  },
  {
    code: "RUTA-TALONARIO-ABROCHADO",
    name: "Talonario abrochado",
    desc: "Talonario con encuadernación por engrapado lateral",
    steps: [
      "Diseño gráfico",
      "Pre-prensa / armado de imposición",
      "Impresión por hoja",
      "Impresión por hoja",
      "Modificación post-producción",
      "Conteo manual",
      "Engrapado (caballete / lateral)",
      "Corte con guillotina",
      "Embalaje",
    ],
    version: "v1",
    usage: 1,
  },
  {
    code: "RUTA-TALONARIO-EMBLOCADO",
    name: "Talonario emblocado",
    desc: "Talonario con encuadernación por engomado/emblocado",
    steps: [
      "Diseño gráfico",
      "Pre-prensa / armado de imposición",
      "Impresión por hoja",
      "Impresión por hoja",
      "Modificación post-producción",
      "Conteo manual",
      "Engomado / emblocado",
      "Corte con guillotina",
      "Embalaje",
    ],
    version: "v1",
    usage: 1,
  },
  {
    code: "RUTA-TARJETA-DIGITAL-STD",
    name: "Tarjeta digital standard",
    desc: "Ruta para tarjetas de visita digitales en papel cortado",
    steps: [
      "Diseño gráfico",
      "Pre-prensa / armado de imposición",
      "Impresión por hoja",
      "Laminado",
      "Corte con guillotina",
      "Modificación post-producción",
      "Embalaje",
    ],
    version: "v1",
    usage: 1,
  },
  {
    code: "RUTA-VINILO-GRAN-FORMATO",
    name: "Vinilo gran formato",
    desc: "Ruta para vinilo adhesivo impreso en gran formato",
    steps: [
      "Diseño gráfico",
      "Impresión por área",
      "Laminado",
      "Plotter de corte",
      "Instalación en sitio",
    ],
    version: "v1",
    usage: 1,
  },
];

function StepChain({ steps }) {
  return (
    <div className="step-chain">
      {steps.map((s, i) => (
        <React.Fragment key={i}>
          <span className="step-chip">
            <span className="ix">{i + 1}.</span>
            <span>{s}</span>
          </span>
          {i < steps.length - 1 && (
            <span className="step-arrow">
              <Ico.Arrow />
            </span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function RutasList({ onOpenRoute }) {
  const [query, setQuery] = React.useState("");

  const matches = RUTAS.filter((r) =>
    !query ||
    r.code.toLowerCase().includes(query.toLowerCase()) ||
    r.name.toLowerCase().includes(query.toLowerCase()) ||
    r.desc.toLowerCase().includes(query.toLowerCase()) ||
    r.steps.some((s) => s.toLowerCase().includes(query.toLowerCase()))
  );

  return (
    <>
      <div className="page-head">
        <div className="title-block">
          <h1>Rutas de producción</h1>
          <div className="sub">
            {RUTAS.length} rutas reusables. Cada ruta es un esqueleto de pasos que los productos pueden referenciar.
          </div>
        </div>
        <button className="btn">Importar</button>
        <button className="btn btn-primary">
          <Ico.Plus />
          Nueva ruta
        </button>
      </div>

      <div className="card">
        <div className="search-card-head">
          <div className="ttl-block">
            <Ico.Route />
            Rutas
          </div>
          <div className="search-inline">
            <Ico.Search />
            <input
              placeholder="Buscar por código, nombre o pasos…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <span className="kbd" style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 3, color: "var(--muted)", background: "var(--surface)" }}>/</span>
          </div>
          <span className="count-pill">{matches.length} de {RUTAS.length}</span>
        </div>

        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 200 }}>Código</th>
              <th style={{ width: 280 }}>Nombre</th>
              <th>Pasos</th>
              <th style={{ width: 90 }}>Versión</th>
              <th style={{ width: 160 }}>Productos que la usan</th>
              <th className="right" style={{ width: 110 }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {matches.map((r) => (
              <tr key={r.code} onClick={() => onOpenRoute?.(r.code)} style={{ cursor: onOpenRoute ? "pointer" : "default" }}>
                <td className="code-cell">{r.code}</td>
                <td className="name-cell">
                  <div className="name">{r.name}</div>
                  <div className="desc">{r.desc}</div>
                </td>
                <td className="steps-cell">
                  <StepChain steps={r.steps} />
                </td>
                <td className="right-cell">
                  <span className="tag version">{r.version}</span>
                </td>
                <td className="right-cell">
                  <span className={`tag usage ${r.usage === 0 ? "zero" : ""}`}>
                    <Ico.Route />
                    {r.usage}
                  </span>
                </td>
                <td className="right right-cell actions">
                  <a style={{ display: "inline-flex", alignItems: "center", gap: 5, fontWeight: 500, fontSize: 12.5, whiteSpace: "nowrap" }} onClick={(e) => { e.stopPropagation(); onOpenRoute?.(r.code); }}>
                    Ver / editar <Ico.External />
                  </a>
                </td>
              </tr>
            ))}
            {matches.length === 0 && (
              <tr>
                <td colSpan={6} style={{ padding: 40, textAlign: "center", color: "var(--muted)", fontSize: 13 }}>
                  Ninguna ruta coincide con "{query}".
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 14, color: "var(--muted)", fontSize: 12, display: "flex", justifyContent: "space-between" }}>
        <span>Mostrando {matches.length} de {RUTAS.length} rutas</span>
        <span style={{ fontFamily: "var(--font-mono)" }}>Última sincronización · hace 2 min</span>
      </div>
    </>
  );
}

Object.assign(window, { RutasList, RUTAS });

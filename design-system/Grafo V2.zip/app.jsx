// Root app — Grafoprint prototype shell.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "logoVariant": "nodes"
}/*EDITMODE-END*/;

const LABEL_BY_KEY = {
  panel: "Panel general",
  catalogo: "Catálogo de productos",
  centros: "Centros de costo",
  maquinaria: "Maquinaria",
  rutas: "Rutas de producción",
  cargos: "Cargos directos",
  impuestos: "Impuestos",
  comisiones: "Comisiones",
  "crear-cotizacion": "Crear cotización",
  clientes: "Clientes",
  proveedores: "Proveedores",
  empleados: "Empleados",
  estaciones: "Estaciones",
  materiales: "Materiales",
  movimientos: "Movimientos",
  administrar: "Administrar suscripción",
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = React.useState({ screen: "catalog" });
  const [activeKey, setActiveKey] = React.useState("catalogo");

  const navigate = (key) => {
    setActiveKey(key);
    if (key === "catalogo") setView({ screen: "catalog" });
    else if (key === "rutas") setView({ screen: "rutas" });
    else if (key === "maquinaria") setView({ screen: "maquinaria" });
    else if (key === "centros") setView({ screen: "centros-costo" });
    else setView({ screen: "placeholder", title: LABEL_BY_KEY[key] || key });
  };

  const openMaquina = (code) => {
    setView({ screen: "maquina-detail", code });
    setActiveKey("maquinaria");
  };

  const backToMaquinaria = () => {
    setView({ screen: "maquinaria" });
    setActiveKey("maquinaria");
  };

  const openRoute = (code) => {
    setView({ screen: "route-editor", code });
    setActiveKey("rutas");
  };

  const backToRutas = () => {
    setView({ screen: "rutas" });
    setActiveKey("rutas");
  };

  const openProduct = (code) => {
    setView({ screen: "wizard", code, step: "identidad" });
  };

  const openWizard = (code, step = "identidad") => {
    setView({ screen: "wizard", code, step });
  };

  const openPasosEditor = () => {
    setView({ screen: "pasos-editor" });
  };

  const handleStepChange = (step) => {
    setView((v) => ({ ...v, step }));
  };

  const backToCatalog = () => {
    setView({ screen: "catalog" });
    setActiveKey("catalogo");
  };

  // Keyboard nav inside wizard
  React.useEffect(() => {
    if (view.screen !== "wizard") return;
    const onKey = (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      const idx = WIZ_STEPS.findIndex((s) => s.key === view.step);
      if (e.key === "ArrowRight" && idx < WIZ_STEPS.length - 1) handleStepChange(WIZ_STEPS[idx + 1].key);
      else if (e.key === "ArrowLeft" && idx > 0) handleStepChange(WIZ_STEPS[idx - 1].key);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const inEditor = view.screen === "pasos-editor";

  return (
    <div className="app">
      <Sidebar
        logoVariant={t.logoVariant}
        activeKey={activeKey}
        onNavigate={navigate}
      />

      <main className="main">
        {!inEditor && (
          <header className="topbar">
            <button className="icon-btn" title="Colapsar panel"><Ico.PanelLeft /></button>
            <div className="spacer" />
            <div className="user-pill">
              <span className="av">LG</span>
              <div className="meta">
                <div className="nm">Lucas German Gomez</div>
                <div className="org">Grafica Corporearte</div>
              </div>
              <Ico.Chev style={{ transform: "rotate(90deg)", color: "var(--muted-2)" }} />
            </div>
          </header>
        )}

        {!inEditor && (
          <div className="content">
            {view.screen === "catalog" && <Catalog onOpenProduct={openProduct} />}
            {view.screen === "rutas" && <RutasList onOpenRoute={openRoute} />}
            {view.screen === "route-editor" && <RouteEditor code={view.code} onBack={backToRutas} />}
            {view.screen === "maquinaria" && <MaquinariaList onOpenMaquina={openMaquina} />}
            {view.screen === "maquina-detail" && <MaquinaDetail code={view.code} onBack={backToMaquinaria} />}
            {view.screen === "centros-costo" && <CentrosCosto />}
            {view.screen === "placeholder" && <Placeholder title={view.title} />}
            {view.screen === "wizard" && (
              <div className="wizard-page">
                <WizardHeader onBack={backToCatalog} />
                <WizardTabs step={view.step} onChange={handleStepChange} />
                {view.step === "identidad" && <StepIdentidad />}
                {view.step === "rutas" && <StepRutas onOpenRoute={openPasosEditor} />}
                {view.step === "pasos" && <StepPasos onOpenRoute={openPasosEditor} />}
                {view.step === "cargos" && <StepCargos />}
                {view.step === "precio" && <StepPricing />}
              </div>
            )}
          </div>
        )}

        {inEditor && (
          <PasosEditor onBack={() => setView({ screen: "wizard", code: "TARJ-PREMIUM-300", step: "pasos" })} />
        )}
      </main>

      <TweaksPanel>
        <TweakSection label="Navegación rápida" />
        <div style={{ padding: "4px 12px 12px", display: "flex", flexDirection: "column", gap: 6 }}>
          <button className="btn" style={{ width: "100%", justifyContent: "center" }} onClick={backToCatalog}>Catálogo de productos</button>
          <button className="btn" style={{ width: "100%", justifyContent: "center" }} onClick={() => { setView({ screen: "rutas" }); setActiveKey("rutas"); }}>Rutas de producción</button>
          <div style={{ height: 1, background: "rgba(0,0,0,.08)", margin: "4px 0" }} />
          <div style={{ fontSize: 10.5, color: "rgba(40,38,30,.65)", marginBottom: 2 }}>Wizard de edición:</div>
          {WIZ_STEPS.map(s => (
            <button
              key={s.key}
              className={`btn ${view.screen === "wizard" && view.step === s.key ? "btn-primary" : ""}`}
              style={{ width: "100%", justifyContent: "flex-start" }}
              onClick={() => openWizard("TARJ-PREMIUM-300", s.key)}
            >
              {s.label}
            </button>
          ))}
          <button className="btn" style={{ width: "100%", justifyContent: "center" }} onClick={openPasosEditor}>
            Editor de pasos (focused)
          </button>
        </div>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
